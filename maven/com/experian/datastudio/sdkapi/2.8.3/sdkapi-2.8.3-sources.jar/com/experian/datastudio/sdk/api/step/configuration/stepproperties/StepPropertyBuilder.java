package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.UICallbackContext;

import java.util.function.*;

/**
 * Builder that defines the common concrete step property builder methods shared by all Step Properties.
 *
 * @param <B> Type of specific concrete step property builder.
 * @param <S> Type of the concrete step property.
 * @param <V> Type of value produce by the concrete step property
 * @since 2.0.0
 */
public interface StepPropertyBuilder<B, S, V> {

    /**
     * Builds the step property object.
     * @return Step property object
     */
    S build();

    /**
     * Configures a supplier which determines if this step property should be disabled
     * @param disabledSupplier callback that returns a result which determines if this step property should be disabled
     * @return Step property builder
     */
    B withIsDisabledSupplier(Predicate<UICallbackContext> disabledSupplier);

    /**
     * Configures a supplier which returns a string label
     * @param labelSupplier callback that returns a string label
     * @return Step property builder
     */
    B withLabelSupplier(Function<UICallbackContext, String> labelSupplier);

    /**
     * Configures a supplier which returns a value produced by the concrete step property
     * @param valueSupplier callback that returns a value produced by the concrete step property
     * @return Step property builder
     * @deprecated Since 2.2.0, custom UserOption is not supported, replaced by {@link #withOnValueChanged(Consumer)}
     */
    @Deprecated
    B withValueSupplier(Function<UICallbackContext, V> valueSupplier);

    /**
     * Configures a callback to update changes when the value changes in the UI
     * @param onValueChanged callback to update changes when the value changes in the UI
     * @param <T> return type
     * @return Step property builder
     * @deprecated Since 2.2.0, custom UserOption is not supported, replaced by {@link #withOnValueChanged(Consumer)}
     */
    @Deprecated
    <T extends UserOption> B withOnValueChanged(BiFunction<T, V, T> onValueChanged);

    /**
     * Configures a callback to update other step properties when the value changes
     * @param onValueChangedContextConsumer callback to update other step properties when the value changes
     * @return Step property builder
     * @since 2.2.0
     */
    B withOnValueChanged(Consumer<StepPropertyOnValueChangedContext> onValueChangedContextConsumer);

    /**
     * Indicates whether to rebuild the index when the property value has changed
     * Default value of rebuildIndex is true - Assume any change to the property value will affect the index by default
     * Allows developers to 'opt out' of re-indexing if they want to do so for performance reasons
     * @param shouldRebuildIndex indicates that index should be rebuilt on changes to property value
     * @return Step property builder
     * @since 2.4.0
     */
    B withShouldRebuildIndex(boolean shouldRebuildIndex);
}
