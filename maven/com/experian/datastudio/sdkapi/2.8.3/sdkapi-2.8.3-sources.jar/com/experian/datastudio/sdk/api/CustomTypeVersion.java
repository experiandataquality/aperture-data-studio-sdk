package com.experian.datastudio.sdk.api;

/**
 * Custom type version of the custom step/parser.
 * @since 2.0.0
 */
public interface CustomTypeVersion {

    /**
     * Returns the custom type version as a string without the patch version.
     * @return String of the custom type version
     */
    String toStringWithoutPatch();

    int getMajorVersion();

    int getMinorVersion();

    int getPatchVersion();
}
