/**
 * Custom Step configuration API
 * Includes step properties
 */
package com.experian.datastudio.sdk.api.step.configuration;