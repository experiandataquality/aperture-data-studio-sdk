package com.experian.datastudio.sdk.api.parser.configuration;

/**
 * Predefined parameter value types that can be applied to custom parser.
 * @since 2.0.0
 */
public enum ParserParameterValueType {
    BOOLEAN,
    STRING,
    INTEGER,
    CHARACTER
}
