package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;

import java.util.List;
import java.util.Optional;

/**
 * Context for input configuration of the custom parser.
 * @since 2.0.0
 */
public interface ConfigurationInputContext {

    /**
     * Returns the list of input columns.
     * @return List of input columns
     */
    List<Column> getColumns();

    /**
     * Returns the input column by ID.
     * @param id column ID
     * @return Column (Optional)
     */
    Optional<Column> getColumnById(String id);

    /**
     * Returns the list of input columns by tag.
     * @param tag data tag
     * @return List of input columns
     * @since 2.3.0
     */
    List<Column> getColumnsByTag(String tag);
}
