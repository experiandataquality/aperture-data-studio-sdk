package com.experian.datastudio.sdk.api.step.processor;

import com.experian.datastudio.sdk.api.step.processor.cache.StepCacheConfigurationBuilder;
import com.experian.datastudio.sdk.api.step.processor.cache.StepCacheManager;

import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.LongFunction;

/**
 * Context for the main processing logic of the custom step.
 *
 * @since 2.0.0
 */
public interface StepProcessorContext {

    /**
     * Returns the input context of the custom step.
     * Input context returned is based on the input ID specified.
     *
     * @param inputId ID of input associated with input context
     * @return {@link ProcessorInputContext} associated with input ID
     */
    Optional<ProcessorInputContext> getInputContext(String inputId);

    /**
     * Update the step execution's progress bar percentage.
     * This method must not used inside {@link OutputColumnManager#onValue(String, LongFunction)} and {@link OutputColumnManager#onValue(String, BiFunction)}
     *
     * @param progressPercent progress percentage. Valid value is between 0.0 to 1.0, e.g. 0.1 is 10%, 0.5 is 50%.
     */
    void progressChanged(double progressPercent);

    /**
     * Update the step execution's progress bar percentage with additional message.
     * This method must not used inside {@link OutputColumnManager#onValue(String, LongFunction)} and {@link OutputColumnManager#onValue(String, BiFunction)}
     *
     * @param message         progress message.
     * @param progressPercent progress percentage. Valid value is between 0.0 to 1.0, e.g. 0.1 is 10%, 0.5 is 50%.
     */
    void progressChanged(String message, double progressPercent);

    /**
     * Returns the step property value based on the step property ID specified.
     *
     * @param <T>            Type of the step property value
     * @param stepPropertyId ID of step property
     * @return Step property value
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);

    /**
     * Returns the cache manager for the custom step.
     *
     * @return {@link StepCacheManager} for the custom step
     */
    StepCacheManager getCacheManager();

    /**
     * Returns the cache configuration builder for the custom step.
     *
     * @return {@link StepCacheConfigurationBuilder} for the custom step
     */
    StepCacheConfigurationBuilder getCacheConfigurationBuilder();

    /**
     * Returns the resource to be used by the custom step.
     *
     * <p>
     * Resources refer to any shared resources that can be created and used throughout processing.
     * The resource should be closed after processing.
     *
     * @param resourceId    ID of resource to be returned
     * @param resourceClass Class of the step resource
     * @param <T>           Type of step resource
     * @return Step resource with specified ID
     */
    <T> Optional<T> getResource(String resourceId, Class<T> resourceClass);

    /**
     * Returns the step setting field value as a string based on the step setting field ID specified.
     *
     * @param stepSettingFieldId ID of the step setting field to be returned
     * @return String value of the step setting field
     */
    Optional<String> getStepSettingFieldValueAsString(String stepSettingFieldId);

    /**
     * Interactive is a flag that set to `true` when the user views the output of a step on the Data Studio Grid (UI).
     * In interactive mode, the evaluator of {@link OutputColumnManager#onValue(String, LongFunction)} will only
     * be executed when the cell is visible.
     * It is set to `false` when running the whole workflow as a Job.
     *
     * @return {@code true} if the execution is interactive, otherwise {@code false}
     */
    boolean isInteractive();

    /**
     * Convenience method to returns the columns selected by the user.
     * It will returns empty list if the column chooser is invalid or the step property is not a column chooser.
     *
     * @param columnChooserId the column chooser's step property ID
     * @return the list of selected {@link InputColumn}
     */
    List<InputColumn> getColumnFromChooserValues(String columnChooserId);

    /**
     * Method to return the index row values
     *
     * @param indexName Index name
     * @param rowIndex  The specified row of the index
     * @return The list of {@link CellValue} at the specified row of the index
     */
    List<CellValue> getIndexRowValues(String indexName, int rowIndex);
}
