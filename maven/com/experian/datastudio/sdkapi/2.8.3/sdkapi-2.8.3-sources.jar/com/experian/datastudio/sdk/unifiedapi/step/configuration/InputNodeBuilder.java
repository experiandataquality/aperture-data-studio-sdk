package com.experian.datastudio.sdk.unifiedapi.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.InputNode;

/**
 * Builder for input node.
 */
public interface InputNodeBuilder {

    /**
     * Sets the id of the input node.
     *
     * @param id id of the input node
     * @return a reference to this builder
     */
    Builder withId(String id);
    
    interface Builder {

        /**
         * Configures the custom label for disconnected input node.
         *
         * @param label a string label
         * @return a reference to this builder
         */
        Builder withLabel(String label);


        /**
         * Builds a input node object.
         *
         * @return a concrete input node object
         */
        InputNode build();
    }

}
