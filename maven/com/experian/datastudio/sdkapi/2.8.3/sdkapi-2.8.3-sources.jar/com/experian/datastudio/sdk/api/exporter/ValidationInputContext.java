package com.experian.datastudio.sdk.api.exporter;

import java.util.List;
import java.util.Optional;

public interface ValidationInputContext {
    /**
     * Returns the columns from the input to a custom step.
     *
     * @return List of {@link GeneratorInputColumn} to the custom file generator
     */
    List<InputColumnMetadata> getColumns();

    /**
     * Returns the column from the input to a custom file generator. Column is specified by the ID.
     *
     * @param id ID of column to be returned
     * @return {@link GeneratorInputColumn} with specified ID
     */
    Optional<InputColumnMetadata> getColumnById(String id);

    /**
     * Returns the list of input columns by tag.
     *
     * @param tag data tag
     * @return List of input columns
     * @since 2.3.0
     */
    List<InputColumnMetadata> getColumnsByTag(String tag);
}
