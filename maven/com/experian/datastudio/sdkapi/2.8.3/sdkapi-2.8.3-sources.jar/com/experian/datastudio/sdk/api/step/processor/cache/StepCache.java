package com.experian.datastudio.sdk.api.step.processor.cache;

import java.io.Closeable;

/**
 * A StepCache is a Map-like data structure that provides temporary storage of application data.
 *
 * @param <K> Key type
 * @param <V> Value type
 * @since 2.0.0
 */
public interface StepCache<K, V> extends Closeable {

    /**
     * Returns the value of the key from the StepCache, or null if the StepCache contains no value for the key.
     * @param key the key
     * @return the cached value; or null if contains no value for the key
     */
    V get(K key);

    /**
     * Determines if the StepCache contains the key.
     * @param key the key
     * @return true if contains the key
     */
    boolean containsKey(K key);

    /**
     * Stores the entry into the StepCache.
     * @param key the key
     * @param value the value to be cached
     */
    void put(K key, V value);

    /**
     * Deletes an entry from the StepCache by the key.
     * @param key the key
     * @return returns false if don't contains the key
     */
    boolean remove(K key);

    /**
     * Removes all the entries of the StepCache.
     */
    void clear();

    /**
     * Closes the StepCache.
     */
    void close();

    /**
     * Determines whether this StepCache instance has been closed.
     * @return true if this StepCache is closed; false if it is still open
     */
    boolean isClosed();

}
