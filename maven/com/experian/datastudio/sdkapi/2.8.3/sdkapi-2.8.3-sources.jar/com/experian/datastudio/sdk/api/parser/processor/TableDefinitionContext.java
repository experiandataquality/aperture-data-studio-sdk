package com.experian.datastudio.sdk.api.parser.processor;

import java.io.InputStream;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Context of table definition of a custom parser.
 * @since 2.0.0
 */
public interface TableDefinitionContext {

    /**
     * Returns a supplier of input stream.
     * @return Supplier of input stream
     */
    Supplier<InputStream> getStreamSupplier();

    /**
     * Returns a handle for parser input that can be used by custom parser implementations
     * needing richer input semantics than a bare stream supplier.
     * <p>
     * Existing implementations are preserved through a default adapter.
     *
     * @return Parser input handle
     * @since 2.9.0
     */
    default ParserInputHandle getInputHandle() {
        return ParserInputHandleFactory.fromSupplier(getStreamSupplier());
    }

    /**
     * Returns file name of the context of table definition.
     * @return File name of the context of table definition
     */
    String getFilename();

    /**
     * Returns parameter configuration of row iterator.
     * @param parameterId the ID of the parameter
     * @return Parameter configuration object
     */
    Optional<Object> getParameterConfiguration(String parameterId);

    /**
     * Returns the factory for table definitions of a custom parser.
     * @return Factory for table definitions of a custom parser
     */
    ParserTableDefinitionFactory getParserTableDefinitionFactory();

    /**
     * Returns the factory for column definitions of a custom parser.
     * @return Factory for column definitions of a custom parser
     */
    ParserColumnDefinitionFactory getParserColumnDefinitionFactory();

    /**
     * Returns the value of the locale parameter selected by the user.
     * @return the selected locale
     * @since 2.2.0
     */
    Locale getLocale();
}

