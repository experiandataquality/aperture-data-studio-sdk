package com.experian.datastudio.sdk.api.parser.configuration;

import com.experian.datastudio.sdk.api.parser.processor.ParserProcessor;

import java.util.List;

/**
 * Parser configuration of a custom parser.
 * Used by {@link com.experian.datastudio.sdk.api.parser.configuration.ParserConfigurationBuilder}
 * @since 2.0.0
 */
public interface ParserConfiguration {

    /**
     * Returns the custom parser ID.
     * @return ID of the custom parser
     */
    String getParserId();

    /**
     * Returns the file extensions that the custom parser supports.
     * @return List of supported file extensions
     */
    List<SupportedFileExtension> getSupportedFileExtensions();

    /**
     * Returns the custom parser parameter definitions.
     * @return List of custom parser parameter definitions
     */
    List<ParameterDefinition> getParameterDefinitions();

    /**
     * Returns the processor to be used for the custom parser.
     * @return Processor to be used for the custom parser
     */
    ParserProcessor getParserProcessor();

    default boolean requiresLocalFile() {
        return false;
    }
}
