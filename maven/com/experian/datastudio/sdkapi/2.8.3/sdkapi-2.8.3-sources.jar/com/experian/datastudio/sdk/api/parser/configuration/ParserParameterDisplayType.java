package com.experian.datastudio.sdk.api.parser.configuration;

/**
 * Predefined parameter display types that can be applied to custom parser.
 * @since 2.0.0
 */
public enum ParserParameterDisplayType {
    TEXTFIELD,
    CHECKBOX,
    CHARSET,
    DELIMITER,
    LOCALE,
    ENDOFLINE,
    QUOTE
}