package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.StepProperty;

/**
 * Step property that takes a boolean value as an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.BooleanStepPropertyBuilder}
 * @since 2.0.0
 */
public interface BooleanStepProperty extends StepProperty<Boolean> {
}
