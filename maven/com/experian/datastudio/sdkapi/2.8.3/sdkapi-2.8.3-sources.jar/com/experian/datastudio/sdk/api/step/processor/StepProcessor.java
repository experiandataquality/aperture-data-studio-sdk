package com.experian.datastudio.sdk.api.step.processor;

import java.util.Map;
import java.util.Optional;

/**
 * The Step Processor contains the main processing logic of the custom step.
 *
 * <p>
 *      One of the 3 main builders required for a custom step:
 *      <ol>
 *          <li>StepConfigurationBuilder</li>
 *          <li>StepProcessorBuilder</li>
 *          <li>CustomTypeMetadataBuilder</li>
 *      </ol>
 *
 * @see     com.experian.datastudio.sdk.api.step.CustomStepDefinition
 * @since   2.0.0
 */
public interface StepProcessor {

    Map<String, StepProcessorIndex> getStepProcessorIndexMap();

    /**
     * Returns the processor function to be used by the custom step.
     * Processor returned is based on the output ID specified.
     * @param outputId Output ID associated with the processor
     * @return {@link StepProcessorFunction} associated with the specified output ID
     */
    Optional<StepProcessorFunction> getStepProcessorFunction(String outputId);

    /**
     * Returns the resource to be used by the custom step.
     *
     * <p>
     *      Resources refer to any shared resources that can be created and used throughout processing.
     *      The resource should be closed after processing.
     * @param resourceId ID of resource to be returned
     * @param resourceClass Class of the step resource
     * @param <T> Type of step resource
     * @return {@link StepResource} with specified ID
     */
    <T> Optional<StepResource<T>> getStepResource(String resourceId, Class<T> resourceClass);

    /**
     * Closes the step processor.
     */
    void close();
}
