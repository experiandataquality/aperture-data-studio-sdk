package com.experian.datastudio.sdk.api.parser.processor;

import java.io.IOException;

/**
 * Iterator for the custom parser that can be closed after processing.
 * Used by {@link com.experian.datastudio.sdk.api.parser.processor.ClosableIteratorBuilder}
 * @since 2.0.0
 */
public interface ClosableIterator<T> {

    /**
     * Returns flag to check if the iterator has next line.
     * @return Flag for the presence of the next line
     * @throws IOException if an I/O error occurs reading from the file
     */
    boolean hasNext() throws IOException;

    /**
     * Returns the next line of the iterator.
     * @return Next line
     * @throws IOException if an I/O error occurs reading from the file
     */
    T next() throws IOException;

    /**
     * Returns the estimated progress value.
     * @return Estimated progress
     * @throws IOException if an I/O error occurs
     */
    double getEstimationProgress() throws IOException;

    /**
     * Closes any streams and releases system resources associated with the iterator.
     * @throws IOException if an I/O error occurs
     */
    void close() throws IOException;
}