package com.experian.datastudio.sdk.api.exporter;

import com.experian.datastudio.sdk.api.step.processor.CellValue;

/**
 * The input column of an input node for a file generator.
 *
 * @see GeneratorInputContext
 */
public interface GeneratorInputColumn extends InputColumnMetadata {
    /**
     * Returns the cell value at the specified row index of the input column.
     *
     * @param rowIndex Row index of value to be retrieved
     * @return {@link CellValue} at specified row
     */
    CellValue getValueAt(long rowIndex);

    /**
     * Returns the String value at the specified row index of the input column.
     *
     * @param rowIndex Row index of value to be retrieved
     * @return String value at specified row
     */
    String getStringValueAt(long rowIndex);
}
