package com.experian.datastudio.sdk.api.parser.configuration;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for a list of supported file extensions of a custom parser.
 * Uses {@link com.experian.datastudio.sdk.api.parser.configuration.SupportedFileExtensionBuilder}
 * @since 2.0.0
 */
public interface SupportedFileExtensionsBuilder {

    /**
     * Adds a new supported file extension through the SupportedFileExtensionBuilder.
     * @param supportedFileExtensionBuilder callback that returns a supported file extension object
     * @return Supported file extensions builder
     */
    SupportedFileExtensionsBuilder add(Function<SupportedFileExtensionBuilder, SupportedFileExtension> supportedFileExtensionBuilder);

    /**
     * Builds a list of supported file extension objects.
     * @return A list of specific concrete supported file extension objects
     */
    List<SupportedFileExtension> build();
}