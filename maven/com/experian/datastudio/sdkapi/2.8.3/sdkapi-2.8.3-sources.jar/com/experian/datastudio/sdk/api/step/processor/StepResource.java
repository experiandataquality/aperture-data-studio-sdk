package com.experian.datastudio.sdk.api.step.processor;

/**
 * Step resource of a custom step.
 * Resources refer to any shared resources that can be created and used throughout processing.
 * The resource should be closed after processing.
 * @since 2.0.0
 */
public interface StepResource<T> extends AutoCloseable {

    /**
     * Returns the resource to be used by the custom step.
     * @param resourceContext Step resource context
     * @return Step resource
     */
    T getResource(StepResourceContext resourceContext);

    /**
     * Returns the class of the resource to be used by the custom step.
     * @return Class of the step resource
     */
    Class<T> getResourceClass();

    /**
     * Returns the ID of the step resource for the custom step.
     * @return ID of the step resource for the custom step
     */
    String getId();

}
