package com.experian.datastudio.sdk.api.step.processor.cache;

/**
 * Defines accessibility of the {@link com.experian.datastudio.sdk.api.step.processor.cache.StepCache}.
 * @since 2.0.0
 */
public enum StepCacheScope {
    /**
     * Only accessible by the steps within the same workflow
     */
    WORKFLOW,
    /**
     * Only accessible by the step that created the StepCache
     */
    STEP
}
