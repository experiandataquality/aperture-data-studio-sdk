package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.StepProperty;

import java.util.List;

/**
 * Step property that provides a column chooser for user to select an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.ColumnChooserStepPropertyBuilder}
 * @since 2.0.0
 */
public interface ColumnChooserStepProperty extends StepProperty<List<String>> {

    /**
     * Returns input ID of step property.
     * @return Input ID of step property
     */
    String getInputId();

    /**
     * Returns the ability for a user to select multiple values from the column chooser.
     * @return Flag of ability for multiple value selection
     */
    boolean isMultipleSelectEnabled();

    /**
     * Returns the ability for a user to select all values from the column chooser.
     * @return Flag of ability for selection of all values
     */
    boolean isSelectAllEnabled();

    /**
     * Returns the ability for a user to search of a specified value in the custom chooser.
     * @return Flag of ability for search of specified value
     */
    boolean isSearchEnabled();
}
