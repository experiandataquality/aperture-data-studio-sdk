package com.experian.datastudio.sdk.api.exporter;

import java.util.List;
import java.util.Optional;

/**
 * The input context of a file generator.
 */
public interface GeneratorInputContext {
    /**
     * Returns the columns from the input to a custom step.
     *
     * @return List of {@link GeneratorInputColumn} to the custom file generator
     */
    List<GeneratorInputColumn> getColumns();

    /**
     * Returns the column from the input to a custom file generator. Column is specified by the ID.
     *
     * @param id ID of column to be returned
     * @return {@link GeneratorInputColumn} with specified ID
     */
    Optional<GeneratorInputColumn> getColumnById(String id);

    /**
     * Returns the row count of the input to a custom file generator.
     *
     * @return Row count of the input to the custom file generator
     */
    long getRowCount();

    /**
     * Returns the list of input columns by tag.
     *
     * @param tag data tag
     * @return List of input columns
     * @since 2.3.0
     */
    List<GeneratorInputColumn> getColumnsByTag(String tag);
}
