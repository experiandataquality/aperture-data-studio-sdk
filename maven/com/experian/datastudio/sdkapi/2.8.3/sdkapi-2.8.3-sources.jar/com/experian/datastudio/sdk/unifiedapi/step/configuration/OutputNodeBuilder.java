package com.experian.datastudio.sdk.unifiedapi.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.OutputNode;

/**
 * Builder for custom step output node.
 */
public interface OutputNodeBuilder {

    Builder withId(String id);
    
    interface Builder {

        Builder withName(String name);

        OutputNode build();
    }

}
