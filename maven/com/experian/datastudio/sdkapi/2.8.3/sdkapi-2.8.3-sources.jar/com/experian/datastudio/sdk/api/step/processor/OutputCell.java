package com.experian.datastudio.sdk.api.step.processor;

/**
 * An object to hold custom step output cell value and it's style.
 * @since 2.0.0
 */
public interface OutputCell {

    /**
     * Returns the custom step output cell value.
     * @return Custom step output cell value
     */
    Object getValue();

    /**
     * Returns the custom step output cell style.
     * @return {@link CustomValueStyle}
     */
    CustomValueStyle getStyle();
}
