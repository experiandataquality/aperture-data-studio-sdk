package com.experian.datastudio.sdk.api.step.processor.cache;

import java.io.Closeable;

/**
 * A manager to get, create and destroy {@link com.experian.datastudio.sdk.api.step.processor.cache.StepCache}.
 * @since 2.0.0
 */
public interface StepCacheManager extends Closeable {

    /**
     * Obtains the StepCache by configuration.
     * @param configuration the configuration
     * @param <K> key type
     * @param <V> value type
     * @return the StepCache or null if not exist
     */
    <K, V> StepCache<K, V> getCache(StepCacheConfiguration<K, V> configuration);

    /**
     * Creates the StepCache based on the configuration.
     * @param configuration the configuration
     * @param <K> key type
     * @param <V> value type
     * @return created StepCache
     */
    <K, V> StepCache<K, V> createCache(StepCacheConfiguration<K, V> configuration);

    /**
     * Obtains or creates StepCache if not exist.
     * @param configuration the configuration
     * @param <K> key type
     * @param <V> value type
     * @return the StepCache
     */
    default <K, V> StepCache<K, V> getOrCreateCache(final StepCacheConfiguration<K, V> configuration) {
        StepCache<K, V> cache = getCache(configuration);
        if (cache == null) {
            cache = createCache(configuration);
        }
        return cache;
    }

    /**
     * Destroys the StepCache by configuration.
     * @param configuration the configuration
     */
    void destroyCache(StepCacheConfiguration configuration);

    /**
     * Closes the StepCacheManager.
     */
    void close();

    /**
     * Determines whether the StepCacheManager instance has been closed.
     * @return true if this StepCacheManager is closed; false if it is still open
     */
    boolean isClosed();

}
