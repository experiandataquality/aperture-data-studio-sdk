package com.experian.datastudio.sdk.api.step.processor;

/**
 * Predefined value types that can be applied to custom step cell.
 * @since 2.0.0
 */
public enum CellValueType {
    NORMAL, NULL, BOOLEAN, ERROR, WARNING, LIST
}
