package com.experian.datastudio.sdk.api.step.configuration;

import java.util.List;

/**
 * Step settings of a custom step. A step setting can have multiple fields.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.CustomStepSettingBuilder}
 * @since 2.0.0
 */
public interface CustomStepSetting {

    /**
     * Returns fields to the step settings of the custom step.
     * @return List of {@link com.experian.datastudio.sdk.api.step.configuration.CustomStepSettingField}
     */
    List<CustomStepSettingField> getFields();

}
