package com.experian.datastudio.sdk.api.step.processor;

/**
 * Factory for builder which defines the step resource of a custom step.
 * @since 2.0.0
 */
public interface StepResourceBuilderFactory {

    /**
     * Returns the builder for step resource to be used by a custom step.
     * @param resourceClass Class of the step resource
     * @param <T> Type associated with the step resource
     * @return {@link StepResourceBuilder} of type T
     */
    <T> StepResourceBuilder<T> forClass(Class<T> resourceClass);
}
