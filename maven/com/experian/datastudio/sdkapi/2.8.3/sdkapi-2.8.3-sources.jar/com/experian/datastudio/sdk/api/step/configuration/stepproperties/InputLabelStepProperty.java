package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.StepProperty;

/**
 * Step property that sets an input label for an input node.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.InputLabelStepPropertyBuilder}
 * @since 2.0.0
 */
public interface InputLabelStepProperty extends StepProperty<String> {

    /**
     * Returns the ID the input node from which values will be used for the input label.
     * @return ID of input node
     */
    String getInputId();

    /**
     * Returns flag for whether this step property must have a value assigned.
     * @return Flag for requiring a value to be assigned
     */
    boolean isRequired();
}
