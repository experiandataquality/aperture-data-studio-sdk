package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.UserOption;

import java.util.List;
import java.util.Optional;

/**
 * Defines the property of a step configured in a workflow.
 *
 * A step property is linked from UI (Data Studio) to {@link UserOption} through 2 methods here:
 * <ul>
 *  <li> {@code onValueChanged}: UI -&gt; {@link UserOption} </li>
 *  <li> {@code getValue}      : UI &lt;- {@link UserOption} </li>
 * </ul>
 *
 * @param <T> The type of value this step property use
 * @since 2.0.0
 */
public interface StepProperty<T> {
    /**
     * Gets the step property id.
     *
     * @return the id.
     */
    String getId();

    /**
     * Updates the option by creating a new {@link UserOption} based on the previous state and a new value from UI.
     *
     * @param oldOption the old {@link UserOption}
     * @param value     the new value
     * @return the new {@link UserOption}
     */
    UserOption onValueChanged(UserOption oldOption, T value);

    /**
     * Gets the value from the {@link UserOption}, via {@code context.getUserOption()}, to be used in rendering UI.
     *
     * @param context the UI context from where the {@link UserOption} could be retrieved.
     * @return The value.
     */
    Optional<T> getValue(UICallbackContext context);

    /**
     * Gets the default value.
     *
     * @return the value.
     */
    default Optional<T> getDefaultValue() {
        return Optional.empty();
    }

    /**
     * Gets the default value.
     *
     * @param context the context from where the {@link UserOption} could be retrieved.
     * @return The value.
     * @since 2.4.0
     */
    default Optional<T> getDefaultValue(DefaultValueContext context) {
        return Optional.empty();
    }

    /**
     * Specifies whether this property has default value defined or not.
     *
     * @return {@code true} if required, otherwise {@code false}.
     */
    default boolean hasDefaultValue() { return false; }

    /**
     * Creates a {@link StepPropertyConfig} to be used to render the step UI.
     *
     * @return the config.
     */
    StepPropertyConfig createConfig();

    /**
     * Specifies whether this property is required to defined or not.
     *
     * @return {@code true} if required, otherwise {@code false}.
     */
    boolean isRequired();

    /**
     * Validates the state of this property (e,g: the value) and return error messages if invalid.
     *
     * @param context the UI context from where the {@link UserOption} could be retrieved.
     * @return List of error messages if this step property is invalid.
     */
    List<String> validateState(UICallbackContext context);

    /**
     * Specifies whether this property is disabled or not.
     * @param context the UI context from where the {@link UserOption} could be retrieved.
     * @return {@code true} if disabled, otherwise {@code false}.
     */
    default boolean isDisabled(UICallbackContext context) {
        return false;
    }

    /**
     * Indicates whether to rebuild the index when the property value has changed
     * Default value of rebuildIndex is true - Assume any change to the property value will affect the index by default
     * Allows for 'opting out' of re-indexing for performance reasons
     * @return {@code true} if index should be rebuilt, otherwise {@code false}.
     */
    default boolean shouldRebuildIndex() { return true; }
}
