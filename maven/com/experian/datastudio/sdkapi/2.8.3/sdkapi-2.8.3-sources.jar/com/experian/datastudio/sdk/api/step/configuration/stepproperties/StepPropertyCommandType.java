package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * INTERNAL USE
 * Predefined step property command type for internal use.
 * @since 2.0.0
 */
public enum StepPropertyCommandType {
    DROPDOWN,
    CHECKBOX
}
