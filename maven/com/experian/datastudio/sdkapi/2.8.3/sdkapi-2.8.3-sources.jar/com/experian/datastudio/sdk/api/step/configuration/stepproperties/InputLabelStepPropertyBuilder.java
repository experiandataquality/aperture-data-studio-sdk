package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Builder for step property that sets an input label for an input node.
 * @since 2.0.0
 */
public interface InputLabelStepPropertyBuilder {

    /**
     * Builds the input label step property object.
     * @return Input label step property object
     */
    InputLabelStepProperty build();

    /**
     * Configures whether this step property must have a value assigned.
     * @param isRequired requires a value to be assigned
     * @return Input label step property builder
     */
    InputLabelStepPropertyBuilder withIsRequired(boolean isRequired);

    /**
     * Configures the custom label for disconnected input node.
     * @param label a string label
     * @return Input label step property builder
     * @since 2.3.0
     */
    InputLabelStepPropertyBuilder withLabel(String label);

    /**
     * @since 2.0.0
     */
    interface InputLabelBuilder {

        /**
         * Configures the input node from which values will be used for the input label.
         * @param inputId ID of input node
         * @return Input label step property builder
         */
        InputLabelStepPropertyBuilder forInputNode(String inputId);
    }
}
