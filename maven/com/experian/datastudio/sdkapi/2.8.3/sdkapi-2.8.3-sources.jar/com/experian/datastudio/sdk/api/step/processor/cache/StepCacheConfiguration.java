package com.experian.datastudio.sdk.api.step.processor.cache;

/**
 * Configuration for getting and creating {@link com.experian.datastudio.sdk.api.step.processor.cache.StepCache}.
 * @param <K> Key type
 * @param <V> Value type
 * @since 2.0.0
 */
public interface StepCacheConfiguration<K, V> {

    /**
     * Returns the name of the cache of the custom step
     * @return Name of cache of custom step
     */
    String getCacheName();

    /**
     * Returns the key type of the step cache configuration.
     * @return Key type
     */
    Class<K> getKeyType();

    /**
     * Returns the value type of the step cache configuration.
     * @return Value type
     */
    Class<V> getValueType();

    /**
     * Returns the time to live for update of the cache.
     * @return {@link StepCacheTtl} object which holds the time duration and unit for time to live of the cache
     */
    StepCacheTtl getTtlForUpdate();

    /**
     * Returns the scope of the cache.
     * @return {@link StepCacheScope} of the cache
     */
    StepCacheScope getScope();

}
