package com.experian.datastudio.sdk.api.parser.configuration;

/**
 * Supported file extension of the custom parser.
 * @since 2.0.0
 */
public interface SupportedFileExtension {
    /**
     * Returns the file extension.
     * @return the file extension
     */
    String getFileExtension();
    /**
     * Returns the name of the file extension.
     * @return the file extension name
     */
    String getFileExtensionName();
    /**
     * Returns the description of the file extension.
     * @return the file extension description
     */
    String getFileExtensionDescription();
}
