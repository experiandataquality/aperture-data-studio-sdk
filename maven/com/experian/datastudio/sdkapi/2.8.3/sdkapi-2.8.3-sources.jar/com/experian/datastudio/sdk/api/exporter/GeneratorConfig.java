package com.experian.datastudio.sdk.api.exporter;

import java.util.List;

/**
 * Configuration of a file generator.
 * Defines the generated file extension, step properties and input nodes.
 */
public interface GeneratorConfig {
    /**
     * Builder to build configuration of file generator.
     */
    interface Builder {
        /**
         * Configures the label for default input node.
         *
         * @param label Label for default input node.
         * @return Generator config builder
         */
        Builder withDefaultInputNodeLabel(String label);

        /**
         * Configures the file extension of the file being generated.
         *
         * @param fileExtension File extension
         * @return Generator config builder
         */
        Builder withDefaultFileExtension(String fileExtension);

        /**
         * Configures additional input nodes.
         * Export step will always have one input node by default.
         *
         * @param secondInputId ID of the additional input node
         * @return Input node generator builder
         */
        InputNodeGeneratorBuilder addAdditionalInputNode(String secondInputId);

        /**
         * Adds a step property to the custom file generator.
         *
         * @param stepPropertyId ID of the step property
         * @return Step property generator builder
         */
        StepPropertyGeneratorBuilder addStepProperty(String stepPropertyId);

        /**
         * Completes the configuration.
         *
         * @return Completed generator configuration
         */
        GeneratorConfig done();
    }

    interface NextAble<T> {
        T next();
    }

    /**
     * Builder to build and configure an input node
     */
    interface InputNodeGeneratorBuilder extends NextAble<Builder> {
        /**
         * Specifies whether this additional input node is required to link to an input or not.
         *
         * @param isRequired This specifies if the input node is required to have input
         * @return Input node generator builder
         */
        InputNodeGeneratorBuilder isRequired(boolean isRequired);

        /**
         * Specifies the custom label for input node.
         *
         * @param label String label for the input node
         * @return Input node generator builder
         */
        InputNodeGeneratorBuilder withLabel(String label);
    }

    /**
     * Builder to build and configure a step property
     */
    interface StepPropertyGeneratorBuilder {
        /**
         * Configures a step property which has a custom chooser as an input.
         *
         * @return Custom chooser property builder
         */
        CustomChooserPropertyBuilder asCustomChooser();

        /**
         * Configures a step property which hold a boolean type value displayed as checkbox.
         *
         * @return Boolean property builder
         */
        BooleanPropertyBuilder asBoolean();
    }

    /**
     * Builder to build and configure a custom chooser
     */
    interface CustomChooserPropertyBuilder extends NextAble<Builder> {
        /**
         * Configures the allowed values in the custom chooser.
         *
         * @param strings All allowed values in custom chooser
         * @return Custom chooser property builder
         */
        CustomChooserPropertyBuilder withChooserValues(List<String> strings);

        /**
         * Configures whether this custom chooser step property must have a value assigned.
         *
         * @param isRequired This specifies whether this custom chooser requires a value to be assigned
         * @return Custom chooser property builder
         */
        CustomChooserPropertyBuilder isRequired(boolean isRequired);
    }

    /**
     * Builder to build and configure a boolean property (displayed as checkbox)
     */
    interface BooleanPropertyBuilder extends NextAble<Builder> {
        /**
         * Configures the default value.
         *
         * @param defaultValue Default value of the property
         * @return Boolean property builder
         */
        BooleanPropertyBuilder withDefaultValue(boolean defaultValue);
    }
}
