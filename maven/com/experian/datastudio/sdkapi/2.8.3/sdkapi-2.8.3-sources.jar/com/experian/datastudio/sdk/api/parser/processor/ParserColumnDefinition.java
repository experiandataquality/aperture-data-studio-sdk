package com.experian.datastudio.sdk.api.parser.processor;

/**
 * Column definition of a custom parser.
 * Used by {@link com.experian.datastudio.sdk.api.parser.processor.ParserColumnDefinitionFactory}
 * @since 2.0.0
 */
public interface ParserColumnDefinition {

    /**
     * Returns the name of the column definition of the custom parser.
     * @return Name of the column definition
     */
    String getName();

    /**
     * Returns the description of the column definition of the custom parser.
     * @return Description of the column definition
     */
    String getDescription();

    /**
     * Returns the parser column data type.
     * @return Parser column data type
     * @deprecated Since 2.2.0. ColumnDataType is no longer used for custom parser
     */
    @Deprecated
    default ParserColumnDataType getColumnDataType() {
        return ParserColumnDataType.UNKNOWN;
    }
}