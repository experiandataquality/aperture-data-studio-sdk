package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Custom step output node.
 * @since 2.0.0
 */
public interface OutputNode extends NodeDefinition {

    /**
     * Returns the output node name.
     * @return name of the output node
     */
    String getName();

}
