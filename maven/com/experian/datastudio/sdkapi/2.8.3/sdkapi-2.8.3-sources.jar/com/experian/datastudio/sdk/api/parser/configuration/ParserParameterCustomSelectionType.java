package com.experian.datastudio.sdk.api.parser.configuration;

/**
 * Predefined parameter custom selection types that can be applied to custom parser.
 *
 * @since 2.6.0
 */
public enum ParserParameterCustomSelectionType {
    DROPDOWN
}