package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;
import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepProperty;

import java.util.List;
import java.util.Optional;

/**
 * The context for the output column builder of the custom step.
 * @since 2.0.0
 */
public interface OutputColumnBuilderContext {
    /**
     * Gets the current user defined option.
     *
     * @param <T> The user option type.
     * @return The user defined option.
     */
    <T extends UserOption> T getUserOption();

    /**
     * Convenience method to get arg value when the user option type is {@code DefaultOption} type.
     *
     * @param stepPropertyId the arg id
     * @param <T>   The type of value the arg would return. e.g {@link StringStepProperty} would return {@code String} value.
     * @return The arg value.
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);

    /**
     * Creates a new output column.
     * @param columnName Name of output column
     * @return Column object
     */
    Column createNewColumn(String columnName);

    /**
     * Returns the configuration input context.
     * @param inputId ID of the input context
     * @return Configuration input context object
     */
    ConfigurationInputContext getInputContext(String inputId);

    /**
     * Convenience method to returns the columns selected by the user.
     * It will returns empty list if the column chooser is invalid or the step property is not a column chooser.
     * @param columnChooserId the column chooser's step property ID
     * @return the list of selected {@link Column}
     */
    List<Column> getColumnFromChooserValues(String columnChooserId);

    /**
     * Returns the step setting field value as a string based on the step setting field ID specified.
     * @param stepSettingFieldId ID of the step setting field to be returned
     * @return String value of the step setting field
     * @since 2.1.0
     */
    Optional<String> getStepSettingFieldValueAsString(String stepSettingFieldId);

}
