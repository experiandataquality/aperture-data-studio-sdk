package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import java.util.List;
import java.util.Optional;

/**
 * Defines the callback to update other step properties.
 * @since 2.2.0
 */
public interface StepPropertyOnValueChangedContext {

    /**
     * Removes the value of a step property.
     * @param stepPropertyId the ID of the step property
     */
    void clearStepPropertyValue(String stepPropertyId);

    /**
     * Sets the string value of a step property.
     * @param stepPropertyId the ID of the step property
     * @param value string value
     */
    void setStepPropertyValue(String stepPropertyId, String value);

    /**
     * Sets the number value of a step property.
     * @param stepPropertyId the ID of the step property
     * @param value number value
     */
    void setStepPropertyValue(String stepPropertyId, Number value);

    /**
     * Sets the custom chooser value of a step property.
     * @param stepPropertyId the ID of the step property
     * @param value custom chooser value
     */
    void setStepPropertyValue(String stepPropertyId, List<String> value);

    /**
     * Sets the boolean value of a step property.
     * @param stepPropertyId the ID of the step property
     * @param value boolean value
     */
    void setStepPropertyValue(String stepPropertyId, boolean value);

    /**
     * Gets the value of a step property.
     * @param <T>   The type of value the step property would return. e.g {@link StringStepProperty} would return {@code String} value.
     * @param stepPropertyId the step property ID
     * @return The step property value.
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);

    /**
     * Gets the step property ID that change this value.
     * @return the parent step property id.
     */
    Optional<String> getChangedByStepPropertyId();
}
