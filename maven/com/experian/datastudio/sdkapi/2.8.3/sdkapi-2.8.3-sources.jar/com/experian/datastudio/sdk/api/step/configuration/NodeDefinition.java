package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Custom step API for input / output node.
 * @since 2.0.0
 */
public interface NodeDefinition {

    /**
     * Returns node type (data/process).
     * @return Node type
     */
    NodeType getType();

    /**
     * Returns ID of the node for the custom step.
     * @return ID of the node
     */
    String getId();

    /**
     * Returns true if the node is input.
     * @return true if the node is input, false otherwise
     */
    boolean isInputNode();

}
