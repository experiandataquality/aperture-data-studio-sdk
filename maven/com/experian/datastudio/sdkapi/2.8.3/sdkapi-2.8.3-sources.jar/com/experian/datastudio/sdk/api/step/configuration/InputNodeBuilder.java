package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Builder for input node.
 * @since 2.0.0
 */
public interface InputNodeBuilder {

    /**
     * Sets the id of the input node.
     * @param id id of the input node
     * @return a reference to this builder
     */
    Builder withId(String id);

    /**
     * @since 2.0.0
     */
    interface Builder {

        /**
         * Sets the type of the input node. Default is DATA.
         * @param nodeType data/process
         * @return a reference to this builder
         */
        Builder withType(NodeType nodeType);

        /**
         * Sets whether the name of the preceding step is displayed on the current step. Default is true.
         * @param labelDisplayed true if display label, false otherwise
         * @return a reference to this builder
         */
        Builder withLabelDisplayed(boolean labelDisplayed);

        /**
         * Configures the custom label for disconnected input node.
         * @param label a string label
         * @return a reference to this builder
         * @since 2.3.0
         */
        Builder withLabel(String label);

        /**
         * Sets whether the input node is mandatory. Default is false.
         * @param required true if mandatory, false otherwise
         * @return a reference to this builder
         */
        Builder withIsRequired(boolean required);

        /**
         * Builds a input node object.
         * @return a concrete input node object
         */
        InputNode build();
    }

}
