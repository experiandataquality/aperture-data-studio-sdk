package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Step property that takes a numerical value as an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.NumberStepPropertyBuilder}
 * @since 2.0.0
 */
public interface NumberStepProperty extends InputTextStepProperty<Number> {

    /**
     * Returns the minimum value that is accepted as an input for the step property.
     * @return Minimum value
     */
    Number getMinValue();

    /**
     * Returns the maximum value that is accepted as an input for the step property.
     * @return Maximum value
     */
    Number getMaxValue();

    /**
     * Returns the ability for a user to enter a decimal value as an input for the the step property.
     * @return Flag for ability for decimal values to be entered into text field
     */
    boolean isDecimalAllowed();
}
