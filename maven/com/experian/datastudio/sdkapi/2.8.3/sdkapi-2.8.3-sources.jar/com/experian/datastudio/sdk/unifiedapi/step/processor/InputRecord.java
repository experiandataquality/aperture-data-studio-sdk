package com.experian.datastudio.sdk.unifiedapi.step.processor;

import com.experian.datastudio.sdk.api.step.Column;
import com.experian.datastudio.sdk.api.step.processor.CellValue;

import java.util.List;

/**
 * Contains step's input of a single row
 */
public interface InputRecord {
    /**
     * Total number of columns
     *
     * @return total number of columns
     */
    long getColumnCount();

    /**
     * Retrieve column schemas
     *
     * @return column schemas
     */
    ColumnSchema getColumnSchemas();

    /**
     * Get value from a column
     *
     * @param columnName
     * @return value
     */
    CellValue getValue(final String columnName);

    /**
     * Get values from specified columns
     *
     * @param columns specified columns
     * @return values
     */
    List<CellValue> getValues(final List<Column> columns);

    /**
     * Get the current record row number starting at 1
     *
     * @return current row number
     */
    long getRowNumber();
}
