package com.experian.datastudio.sdk.unifiedapi.step;

import com.experian.datastudio.sdk.api.CustomDefinition;
import com.experian.datastudio.sdk.unifiedapi.step.configuration.UnifiedStepConfiguration;
import com.experian.datastudio.sdk.unifiedapi.step.configuration.UnifiedStepConfigurationBuilder;

public interface UnifiedCustomStepAPI extends CustomDefinition {
    /**
     * Creates the custom step configuration.
     * @see com.experian.datastudio.sdk.api.step.configuration.StepConfiguration
     * @param configurationBuilder Step configuration builder
     * @return Step configuration of the custom step
     */
    UnifiedStepConfiguration createConfiguration(UnifiedStepConfigurationBuilder configurationBuilder);
}
