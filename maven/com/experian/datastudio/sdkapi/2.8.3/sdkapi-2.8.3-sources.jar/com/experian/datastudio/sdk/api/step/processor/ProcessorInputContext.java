package com.experian.datastudio.sdk.api.step.processor;

import java.util.List;
import java.util.Optional;

/**
 * Context for the input to the processor of a custom step.
 * @since 2.0.0
 */
public interface ProcessorInputContext {

    /**
     * Returns the columns from the input to a custom step.
     * @return List of {@link InputColumn} to the custom step
     */
    List<InputColumn> getColumns();

    /**
     * Returns the column from the input to a custom step. Column is specified by the ID.
     * @param id ID of column to be returned
     * @return {@link InputColumn} with specified ID
     */
    Optional<InputColumn> getColumnById(String id);

    /**
     * Returns the row count of the input to a custom step.
     * @return Row count of the input to the custom step
     */
    long getRowCount();

    /**
     * Returns the list of input columns by tag.
     * @param tag data tag
     * @return List of input columns
     * @since 2.3.0
     */
    List<InputColumn> getColumnsByTag(String tag);
}