package com.experian.datastudio.sdk.api.parser.processor;

import java.io.InputStream;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Path;
import java.util.function.Supplier;

/**
 * Factory methods for {@link ParserInputHandle}.
 *
 * @since 2.9.0
 */
public final class ParserInputHandleFactory {

    private ParserInputHandleFactory() {
        // Utility class
    }

    /**
     * Creates a non-repeatable parser input handle from a stream supplier.
     *
     * @param streamSupplier Input stream supplier
     * @return Parser input handle
     */
    public static ParserInputHandle fromSupplier(final Supplier<InputStream> streamSupplier) {
        return new DefaultParserInputHandle(streamSupplier, null, null);
    }

    /**
     * Creates a parser input handle with repeatability and local path metadata.
     *
     * @param streamSupplier Input stream supplier
     * @param localPath Local backing path, if any
     * @return Parser input handle
     */
    public static ParserInputHandle fromSupplier(final Supplier<InputStream> streamSupplier,
                                                 final Path localPath) {
        return new DefaultParserInputHandle(streamSupplier, localPath, null);
    }

    /**
     * Creates a parser input handle with repeatability, local path metadata and seekable channel support.
     *
     * @param streamSupplier Input stream supplier
     * @param localPath Local backing path, if any
     * @param seekableChannelSupplier Seekable channel supplier, if supported
     * @return Parser input handle
     */
    public static ParserInputHandle fromSupplier(final Supplier<InputStream> streamSupplier,
                                                 final Path localPath,
                                                 final Supplier<SeekableByteChannel> seekableChannelSupplier) {
        return new DefaultParserInputHandle(streamSupplier, localPath, seekableChannelSupplier);
    }
}

