package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for the output layout of the custom step.
 * Used by StepConfigurationBuilder.
 * @since 2.0.0
 */
public interface OutputLayoutBuilder {

    /**
     * Specifies which output node to build layout for.
     * @param outputId ID of output node
     * @param outputColumnBuilder builder for output columns
     * @return a reference to this object
     */
    OutputLayoutBuilder forOutputNode(String outputId, Function<OutputColumnBuilder, OutputLayout> outputColumnBuilder);

    /**
     * Builds a list of output layout objects.
     * @return A list of specific concrete output layout objects.
     */
    List<OutputLayout> build();

    /**
     * @since 2.0.0
     */
    interface OutputColumnBuilder {

        /**
         * Adds a list of columns to the output layout of the custom step.
         * @param columnsAdder callback that returns a list of column objects to be added to the output layout
         * @return Output column builder
         */
        OutputColumnBuilder addColumns(Function<OutputColumnBuilderContext, List<Column>> columnsAdder);

        /**
         * Adds a column to the output layout of the custom step.
         * @param header header of the column to be added to the output layout
         * @return Output column builder
         */
        OutputColumnBuilder addColumn(String header);

        /**
         * Builds an output layout object for the custom step.
         * @return Specific concrete output layout object
         */
        OutputLayout build();
    }
}
