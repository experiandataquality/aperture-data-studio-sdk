package com.experian.datastudio.sdk.api.step.processor;

/**
 * Predefined value data types that can be applied to custom step cell.
 * @since 2.0.0
 */
public enum CellValueDataType {

    // Do not re-order these (otherwise data type sort order will change)
    NULL,
    NUMBER,
    ALPHANUMERIC,
    DATE,
    BOOLEAN;

    /**
     * Returns the sort order of the data types.
     * @return Sort order of the data types
     */
    public int getSortOrdinal() {
        // Determines sort order of data types
        return ordinal();
    }
}
