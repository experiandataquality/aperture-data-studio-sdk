package com.experian.datastudio.sdk.api.parser.processor;

import java.util.List;

/**
 * Table definition of a custom parser.
 * @since 2.0.0
 */
public interface ParserTableDefinition {

    /**
     * Returns the ID of the table definition.
     * @return ID of the table definition.
     */
    String getId();

    /**
     * Returns the description of the table definition.
     * @return Description of the table definition.
     */
    String getDescription();

    /**
     * Returns the name of the table definition.
     * @return Name of the table definition.
     */
    String getName();

    /**
     * Returns the list of column definitions of the custom parser.
     * @return List of column definitions of the custom parser
     */
    List<ParserColumnDefinition> getColumns();

    /**
     * Adds a column definition to the parser table definition.
     * @param columnDefinition Column definition of the custom parser to be added
     */
    void addColumn(ParserColumnDefinition columnDefinition);
}
