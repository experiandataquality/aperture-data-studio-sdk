package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.StepProperty;

import java.util.Optional;

/**
 * Step property that takes a user input in a text field as an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.InputTextStepPropertyBuilder}
 * @since 2.0.0
 */
public interface InputTextStepProperty<T> extends StepProperty<T> {

    /**
     * Returns flag for whether this step property must have a value assigned.
     * @return Flag for requirement of a value to be assigned
     */
    boolean isRequired();

    /**
     * Returns the placeholder of the input text field.
     * A placeholder is a hint is displayed in the input field before the user enters a value.
     * @return PlaceHolder hint to be displayed in input field
     */
    String getPlaceHolder();

    /**
     * Returns the default value of the input text field.
     * @return Value of default text field value
     */
    @Override
    Optional<T> getDefaultValue();
}
