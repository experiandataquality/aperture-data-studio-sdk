package com.experian.datastudio.sdk.api.step.processor.cache;

import java.util.concurrent.TimeUnit;

/**
 * Builder for configuring a cache of a custom step.
 * @see     com.experian.datastudio.sdk.api.step.processor.cache.StepCacheConfiguration
 * @since   2.0.0
 */
public interface StepCacheConfigurationBuilder {

    /**
     * Configures the name of the cache of the custom step
     * @param cacheName name of cache of custom step
     * @return Time to live for update builder
     */
    TtlForUpdateBuilder withCacheName(String cacheName);

    /**
     * @since 2.0.0
     */
    interface TtlForUpdateBuilder {

        /**
         * Configures the time to live for update of the cache.
         * @param time duration for time to live
         * @param timeUnit unit used for measuring time
         * @return Scope builder
         */
        ScopeBuilder withTtlForUpdate(long time, TimeUnit timeUnit);
    }

    /**
     * @since 2.0.0
     */
    interface ScopeBuilder {

        /**
         * Configures the scope of the cache.
         * @param scope scope of the cache
         * @return Builder for step cache configuration
         */
        Builder withScope(StepCacheScope scope);
    }

    /**
     * @since 2.0.0
     */
    interface Builder {

        /**
         * Builds the step cache configuration object.
         * @param keyType Key Type
         * @param valueType Value Type
         * @param <K> Key type
         * @param <V> Value type
         * @return Specific concrete step cache configuration object
         */
        <K, V> StepCacheConfiguration<K, V> build(Class<K> keyType, Class<V> valueType);
    }

}
