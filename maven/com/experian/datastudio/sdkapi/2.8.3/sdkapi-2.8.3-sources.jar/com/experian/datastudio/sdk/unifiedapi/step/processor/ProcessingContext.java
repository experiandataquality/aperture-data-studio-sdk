package com.experian.datastudio.sdk.unifiedapi.step.processor;

import com.experian.datastudio.sdk.api.step.Column;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepProperty;
import com.experian.datastudio.sdk.api.step.processor.InputColumn;

import java.util.List;
import java.util.Optional;

public interface ProcessingContext {
    /**
     * Convenience method to get arg value when the user option type is {@code DefaultOption} type.
     *
     * @param stepPropertyId the arg id
     * @param <T>            The type of value the arg would return. e.g {@link StringStepProperty} would return {@code String} value.
     * @return The arg value.
     */
    <T> T getStepPropertyValue(String stepPropertyId, Class<T> type, T defaultValue);

    /**
     * Convenience method to returns the columns selected by the user.
     * It will return empty list if the column chooser is invalid or the step property is not a column chooser.
     *
     * @param columnChooserId the column chooser's step property ID
     * @return the list of selected {@link Column}
     */
    List<Column> getColumnFromChooserValues(String columnChooserId);

    /**
     * Returns the step setting field value as a string based on the step setting field ID specified.
     *
     * @param stepSettingFieldId ID of the step setting field to be returned
     * @return String value of the step setting field
     */
    Optional<String> getStepSettingFieldValueAsString(final String stepSettingFieldId);

    /**
     * Interactive is a flag that set to `true` when the user views the output of a step on the Data Studio Grid (UI).
     * It is set to `false` when running the whole workflow as a Job.
     *
     * @return {@code true} if the execution is interactive, otherwise {@code false}
     */
    boolean isInteractive();

    /**
     * Returns the columns from the input to a custom step.
     *
     * @return List of {@link InputColumn} to the custom step
     */
    List<Column> getColumns();

    /**
     * Returns the column from the input to a custom step. Column is specified by the ID.
     *
     * @param id ID of column to be returned
     * @return {@link InputColumn} with specified ID
     */
    Optional<Column> getColumnById(String id);

    /**
     * Returns the list of input columns by tag.
     *
     * @param tag data tag
     * @return List of input columns
     * @since 2.3.0
     */
    List<Column> getColumnsByTag(String tag);

    /**
     * Returns the builder class for output record
     *
     * @return builder class for output record
     */
    OutputRecordBuilder getOutputBuilder();
}