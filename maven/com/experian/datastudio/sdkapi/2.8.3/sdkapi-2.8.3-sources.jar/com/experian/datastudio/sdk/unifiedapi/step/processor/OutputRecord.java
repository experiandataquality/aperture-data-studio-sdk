package com.experian.datastudio.sdk.unifiedapi.step.processor;

import java.util.function.Supplier;

/**
 * Contains step's results of a single row
 */
public interface OutputRecord {
    OutputRecord EMPTY = new OutputRecord() {
        @Override
        public Supplier<Object> getValueAt(String columnName) {
            return null;
        }

        @Override
        public boolean hasColumn(String columnName) {
            return false;
        }

        @Override
        public NodeIndex getNodeIndex() {
            return null;
        }
    };

    /**
     * Returns cell value of the specified column
     *
     * @param columnName
     * @return value
     */
    Supplier<Object> getValueAt(String columnName);

    /**
     * Determine whether output record has the specified column
     *
     * @param columnName
     * @return
     */
    boolean hasColumn(String columnName);

    /**
     * The output index of this output record belonged to
     *
     * @return output node index
     */
    NodeIndex getNodeIndex();
}
