package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Predefined custom chooser item for internal use.
 * @since 2.3.0
 */
public interface CustomChooserItem {
    /**
     * Gets the value of the custom chooser.
     * @return The value of the custom chooser.
     */
    String getValue();

    /**
     * Gets the description of the custom chooser.
     * @return the display name of the custom chooser.
     */
    String getDisplayName();
}
