package com.experian.datastudio.sdk.api.parser.configuration;

/**
 * Builder for a supported file extension of a custom parser
 * Used by {@link com.experian.datastudio.sdk.api.parser.configuration.SupportedFileExtensionsBuilder}
 * @since 2.0.0
 */
public interface SupportedFileExtensionBuilder {

    /**
     * Configures the file extension that the custom parser supports.
     * e.g. csv, json, xml, metro2
     * @param supportedFileExtension extension of the file that the custom parser supports
     * @return File extension name builder
     */
    FileExtensionNameBuilder withSupportedFileExtension(String supportedFileExtension);

    /**
     * @since 2.0.0
     */
    interface FileExtensionNameBuilder {

        /**
         * Configures the name of the file extension that the custom parser supports.
         * e.g. Comma Separated Value, JavaScript Object Notation, Extensible Markup Language, Metro 2
         * @param supportedFileExtensionName name of the extension of the file that the custom parser supports
         * @return File extension description builder
         */
        FileExtensionDescriptionBuilder withFileExtensionName(String supportedFileExtensionName);
    }

    /**
     * @since 2.0.0
     */
    interface FileExtensionDescriptionBuilder {

        /**
         * Configures the description of the file extension that the custom parser supports.
         * @param supportedFileExtensionDescription description of the extension of the file that the custom parser supports
         * @return File extension builder
         */
        FileExtensionBuilder withFileExtensionDescription(String supportedFileExtensionDescription);
    }

    /**
     * @since 2.0.0
     */
    interface FileExtensionBuilder {

        /**
         * Builds a supported file extension object.
         * @return Specific concrete file extension object
         */
        SupportedFileExtension build();
    }
}
