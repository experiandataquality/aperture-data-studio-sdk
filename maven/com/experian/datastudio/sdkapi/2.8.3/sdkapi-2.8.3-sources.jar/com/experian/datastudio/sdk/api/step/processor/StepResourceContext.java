package com.experian.datastudio.sdk.api.step.processor;

import java.util.Optional;

/**
 * Context of the step resource of a custom step.
 * @since 2.0.0
 */
public interface StepResourceContext {

    /**
     * Returns the value of the step property with specified step property ID.
     * @param <T> Type of the step property value
     * @param stepPropertyId ID of the step property to be returned
     * @return Step property value
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);
}
