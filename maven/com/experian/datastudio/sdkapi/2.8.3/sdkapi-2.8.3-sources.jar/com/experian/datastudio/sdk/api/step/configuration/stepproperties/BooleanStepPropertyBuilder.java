package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.DefaultValueContext;

import java.util.function.Function;

/**
 * Builder for step property that takes a boolean value as an input.
 * @since 2.0.0
 */
public interface BooleanStepPropertyBuilder extends StepPropertyBuilder<BooleanStepPropertyBuilder, BooleanStepProperty, Boolean> {

    /**
     * Configures the default value of the step property that takes a boolean value as an input.
     * @param value default boolean value
     * @return Boolean step property builder
     */
    BooleanStepPropertyBuilder withDefaultValue(boolean value);

    /**
     * Configures the default value of the input text field with context.
     * @param defaultValueSupplier supplier for the default text field value
     * @return Input text step property builder
     * @since 2.4.0
     */
    BooleanStepPropertyBuilder withDefaultValue(Function<DefaultValueContext, Boolean> defaultValueSupplier);
}
