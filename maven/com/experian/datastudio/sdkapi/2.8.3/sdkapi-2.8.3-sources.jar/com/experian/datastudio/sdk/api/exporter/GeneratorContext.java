package com.experian.datastudio.sdk.api.exporter;

/**
 * The context for generator.
 */
public interface GeneratorContext {

    /**
     * Returns the row count of a specific input using ID.
     *
     * @param inputId ID of the input node to get row count
     * @return Row count of specified input
     */
    long getInputRowCounts(String inputId);

    /**
     * Returns the row count of the first input.
     *
     * @return Row count of the first input
     */
    long getFirstInputRowCount();

    /**
     * Writes data to file context.
     *
     * @param exportData Data to write
     */
    void write(Object exportData);

    /**
     * Returns the value of type String at a specific column and row from first input.
     *
     * @param columnName Column's name of value to be retrieved
     * @param rowIndex   Row index of value to be retrieved
     * @return The value in selected column and row from first input
     */
    String getFirstInputValue(String columnName, long rowIndex);

    /**
     * Returns the value of specified type at a specific column and row from first input.
     *
     * @param columnName Column's name
     * @param rowIndex   Row index of value to be retrieved
     * @param type       The class of the value's type
     * @param <T>        This describes the type parameter
     * @return The value with specified type in selected column and row from first input
     */
    <T> T getFirstInputValue(String columnName, long rowIndex, Class<T> type);

    /**
     * Returns the value of type String at a specific column and row from a specific input.
     *
     * @param inputId    ID of the input node to get value from
     * @param columnName Column's name of value to be retrieved
     * @param rowIndex   Row index of value to be retrieved
     * @return The value in selected column and row from the specified input
     */
    String getInputValue(String inputId, String columnName, long rowIndex);

    /**
     * Returns the value of specified type from a specific input, column and row.
     *
     * @param inputId    ID of the input node to get value from
     * @param columnName Column's name of value to be retrieved
     * @param rowIndex   Row index of value to be retrieved
     * @param type       The class of the value's type
     * @param <T>        This describes the type parameter
     * @return The value with specified type in selected input, column and row
     */
    <T> T getInputValue(String inputId, String columnName, long rowIndex, Class<T> type);

    /**
     * Returns the value from a specific custom chooser
     *
     * @param customChooserId The custom chooser's ID
     * @param type            The class of the value's type
     * @param <T>             This describes the type parameter
     * @return The value from the specified custom chooser
     */
    <T> T getChooserValue(String customChooserId, Class<T> type);

    /**
     * Returns the default input context
     *
     * @return Default input context
     */
    GeneratorInputContext getDefaultInputContext();

    /**
     * Returns a specific input node using ID
     *
     * @param inputId ID of the input node
     * @return The input context with the specified ID
     */
    GeneratorInputContext getAdditionalInputContext(final String inputId);

    /**
     * Returns the boolean value from a property
     *
     * @param propertyId The property id
     * @return The value from the specific property
     */
    boolean getPropertyValueBoolean(String propertyId);
}
