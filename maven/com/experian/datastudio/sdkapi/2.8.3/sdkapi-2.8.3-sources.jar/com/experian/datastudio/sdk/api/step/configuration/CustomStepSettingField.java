package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Step settings data class.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.CustomStepSettingFieldBuilder}
 * @since 2.0.0
 */
public interface CustomStepSettingField {

    /**
     * Returns ID of the field step setting for the custom step.
     * @return ID of the field step setting
     */
    String getId();

    /**
     * Returns name of the field step setting for the custom step.
     * @return name of the field step setting
     */
    String getName();

    /**
     * Determines if the field step setting is necessary.
     * @return {@code true} if the field step setting is necessary, otherwise {@code false}
     */
    boolean isRequired();

    /**
     * Returns type of the field step setting for the custom step.
     * @return type of the field step setting
     * @since 2.1.0
     */
    StepSettingType getType();
}
