package com.experian.datastudio.sdk.api.parser.processor;

/**
 * Factory for column definitions of a custom parser.
 * @since 2.0.0
 */
public interface ParserColumnDefinitionFactory {

    /**
     * Creates column definition of custom parser.
     * @param name Name of the column definition
     * @param description Description of the column definition
     * @return Parser column definition
     */
    ParserColumnDefinition createColumnDefinition(String name, String description);

    /**
     * Creates column definition of custom parser.
     * @param name           Name of the column definition
     * @param description    Description of the column definition
     * @param columnDataType Parser column data type
     * @return Parser column definition
     * @deprecated Since 2.2.0. ColumnDataType is no longer used for custom parser
     */
    @Deprecated
    default ParserColumnDefinition createColumnDefinition(String name, String description, ParserColumnDataType columnDataType) {
        return createColumnDefinition(name, description);
    }
}
