package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;

import java.util.List;

/**
 * Context for step property when setting default value.
 * Extension of DefaultValueContext.
 * @since 2.4.0
 */
public interface DefaultColumnContext extends DefaultValueContext {

    /**
     * Returns the columns based on the column tag.
     * @param tag the column tag
     * @return list of columns
     */
    List<Column> getColumnsByTag(String tag);

    /**
     * Returns the column based on the column index.
     * @param index the column index
     * @return selected column
     */
    Column getColumnByIndex(int index);
}
