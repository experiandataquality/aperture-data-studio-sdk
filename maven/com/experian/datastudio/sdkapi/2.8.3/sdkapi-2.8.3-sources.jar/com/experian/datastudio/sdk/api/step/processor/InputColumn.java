package com.experian.datastudio.sdk.api.step.processor;

import java.util.Collection;

/**
 * Defines an input column of a custom step.
 * @since 2.0.0
 */
public interface InputColumn {

    /**
     * Returns the ID of the input column of a custom step.
     * @return ID of the input column
     */
    String getId();

    /**
     * Returns the name of the input column of a custom step.
     * @return Name of the input column
     */
    String getName();

    /**
     * Returns the cell value at the specified row index of the input column.
     * @param rowIndex Row index of value to be retrieved
     * @return {@link CellValue} at specified row
     */
    CellValue getValueAt(long rowIndex);

    /**
     * Returns the String value at the specified row index of the input column.
     * @param rowIndex Row index of value to be retrieved
     * @return String value at specified row
     */
    String getStringValueAt(long rowIndex);

    /**
     * Returns the data tags associated with the column.
     * @return Collection of data tags associated with the column
     * @since 2.3.0
     */
    Collection<String> getTags();
}