package com.experian.datastudio.sdk.api.parser.configuration;

import java.io.InputStream;
import java.util.function.Supplier;

/**
 * Parameter context of a custom parser.
 * @since 2.0.0
 */
public interface ParameterContext {

    /**
     * Returns the input stream supplier for a custom parser.
     * @return Input stream supplier
     */
    Supplier<InputStream> getStreamSupplier();
}
