package com.experian.datastudio.sdk.api.exporter;

public interface ValidationResult {
}
