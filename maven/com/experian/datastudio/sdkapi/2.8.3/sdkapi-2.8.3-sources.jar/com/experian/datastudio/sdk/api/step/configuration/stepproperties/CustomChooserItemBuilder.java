package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import java.util.List;

/**
 * Builder for custom chooser item.
 * @since 2.3.0
 */
public interface CustomChooserItemBuilder {

    /**
     * Adds a chooser item to custom chooser.
     * @param displayName the display name of the chooser item.
     * @param value the value of the chooser item.
     * @return Custom chooser item builder.
     */
    CustomChooserItemBuilder add(final String displayName, final String value);

    /**
     * Builds a list of custom chooser items.
     * @return Specific concrete custom chooser items.
     */
    List<CustomChooserItem> build();
}
