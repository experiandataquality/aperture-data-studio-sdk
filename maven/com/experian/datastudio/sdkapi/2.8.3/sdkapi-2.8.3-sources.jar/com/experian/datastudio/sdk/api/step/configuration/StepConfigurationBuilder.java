package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.UserOption;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Builder for step configuration of a custom step.
 *
 * <p>
 *      Defines the custom step nodes, step properties, output layout and settings.
 *
 * <p>
 *      One of the 3 main builders required for a custom step:
 *      <ol>
 *          <li>StepConfigurationBuilder</li>
 *          <li>StepProcessorBuilder</li>
 *          <li>CustomTypeMetadataBuilder</li>
 *      </ol>
 *
 * @see     com.experian.datastudio.sdk.api.step.CustomStepDefinition
 * @since   2.0.0
 */
public interface StepConfigurationBuilder {

    /**
     * Configures the input and output nodes that are associated with the custom step.
     * @param nodeBuilder list of Node Definitions
     * @return Add step properties builder
     */
    AddStepPropertiesBuilder withNodes(Function<StepNodeBuilder, List<NodeDefinition>> nodeBuilder);

    /**
     * @since 2.0.0
     */
    interface AddStepPropertiesBuilder {

        /**
         * Configures the step properties that are associated with the custom step.
         * @param stepPropertyBuilder list of Step Properties
         * @return Complete and output definition builder
         */
        IsCompleteAndOutputDefinitionBuilder withStepProperties(Function<StepPropertiesBuilder, List<StepProperty>> stepPropertyBuilder);
    }

    /**
     * @since 2.0.0
     */
    interface IsCompleteBuilder {

        /**
         * Configures the handler to determine if the custom step is complete.
         * @param isCompleteHandler callback to determine if custom step is complete
         * @return Output definition builder
         */
        OutputDefinitionBuilder withIsCompleteHandler(Predicate<UICallbackContext> isCompleteHandler);
    }

    /**
     * @since 2.0.0
     */
    interface OutputDefinitionBuilder {

        /**
         * Configures the output layout of the custom step.
         * @param outputLayoutBuilder builder to configure individual output layout
         * @return Configuration builder
         */
        ConfigurationBuilder withOutputLayouts(Function<OutputLayoutBuilder, List<OutputLayout>> outputLayoutBuilder);
    }

    /**
     * @since 2.0.0
     */
    interface IsCompleteAndOutputDefinitionBuilder extends IsCompleteBuilder, OutputDefinitionBuilder {
    }

    /**
     * @since 2.0.0
     */
    interface ConfigurationBuilder {

        /**
         * Configures the default configuration option of the custom step.
         * @param userOption user option
         * @return Configuration builder
         */
        ConfigurationBuilder withDefaultOptions(UserOption userOption);

        /**
         * Configures a step setting of the custom step.
         * @param builder builder for custom step setting
         * @return Configuration builder
         */
        ConfigurationBuilder withStepSetting(Function<CustomStepSettingBuilder, CustomStepSetting> builder);

        /**
         * Configures the custom step icon to be displayed.
         * @param icon icon reference
         * @return Configuration builder
         */
        ConfigurationBuilder withIcon(StepIcon icon);

        /**
         * Builds the step configuration object.
         * @return Specific concrete step configuration object
         */
        StepConfiguration build();
    }

}
