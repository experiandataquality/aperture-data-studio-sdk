package com.experian.datastudio.sdk.unifiedapi.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.*;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for a node of unified custom step.
 * Used by UnifiedStepConfigurationBuilder.
 */
public interface UnifiedStepNodeBuilder {

    /**
     * Adds an input node to the custom step.
     *
     * @param inputId ID of the input node
     * @return Step node builder
     */
    UnifiedOutputNodeBuilder addInputNode(String inputId);

    /**
     * Adds an input node to the custom step.
     *
     * @param function function to build input node
     * @return Step node builder
     */
    UnifiedOutputNodeBuilder addInputNode(Function<InputNodeBuilder, InputNode> function);

    interface UnifiedOutputNodeBuilder {
        /**
         * Adds an output node to the custom step.
         *
         * @param outputId ID of the output node
         * @return Step node builder
         */
        UnifiedNodeDefinitionBuilder addOutputNode(String outputId);

        /**
         * Adds an output node to the custom step.
         *
         * @param function function to build the output node
         * @return Step node builder
         */
        UnifiedNodeDefinitionBuilder addOutputNode(Function<OutputNodeBuilder, OutputNode> function);
    }

    interface UnifiedNodeDefinitionBuilder {
        /**
         * Builds a list of node definition objects.
         *
         * @return A list of specific concrete node definition objects
         */
        List<NodeDefinition> build();
    }
}
