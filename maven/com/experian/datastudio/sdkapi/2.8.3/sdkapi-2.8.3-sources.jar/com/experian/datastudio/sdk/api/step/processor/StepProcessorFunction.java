package com.experian.datastudio.sdk.api.step.processor;

/**
 * Function defining step processor logic for a custom step.
 * @see     com.experian.datastudio.sdk.api.step.processor.StepProcessor
 * @since   2.0.0
 */
@FunctionalInterface
public interface StepProcessorFunction {

    /**
     * Executes the step processor function as defined in the method.
     * @param context Context provided for step processor function to be applied
     * @param columnManager Manager for output columns
     * @return Row index
     */
    long execute(StepProcessorContext context, OutputColumnManager columnManager);
}
