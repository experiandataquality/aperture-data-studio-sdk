package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.DefaultValueContext;
import com.experian.datastudio.sdk.api.step.configuration.UICallbackContext;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * Builder for step property that provides a custom chooser for user to select an input.
 * @since 2.0.0
 */
public interface CustomChooserStepPropertyBuilder extends StepPropertyBuilder<CustomChooserStepPropertyBuilder, CustomChooserStepProperty, List<String>> {


    /**
     * Configures the ability for a user to select multiple values from the custom chooser.
     * @param isEnabled enables multiple value selection
     * @return Custom chooser step property builder
     */
    CustomChooserStepPropertyBuilder withMultipleSelect(boolean isEnabled);

    /**
     * Configures the ability for a user to select all values from the custom chooser.
     * @param isEnabled enables selection of all values
     * @return Custom chooser step property builder
     */
    CustomChooserStepPropertyBuilder withAllowSelectAll(boolean isEnabled);

    /**
     * Configures the ability for a user to search for a specified value in the custom chooser.
     * @param isEnabled enables search for specified value
     * @return Custom chooser step property builder
     */
    CustomChooserStepPropertyBuilder withAllowSearch(boolean isEnabled);

    /**
     * Configures whether this step property must have a value assigned.
     * @param isRequired requires a value to be assigned
     * @return Custom chooser step property builder
     */
    CustomChooserStepPropertyBuilder withIsRequired(boolean isRequired);

    /**
     * Configures the default value of the input text field with context.
     * @param defaultValueSupplier supplier for the default text field value
     * @return Input text step property builder
     * @since 2.4.0
     */
    CustomChooserStepPropertyBuilder withDefaultValue(Function<DefaultValueContext, List<String>> defaultValueSupplier);

    /**
     * @since 2.0.0
     */
    interface AllowValuesProviderBuilder {

        /**
         * Configures the allowed provider from which values will be used populate the column chooser
         * @param allowValuesProvider callback that returns a list of allowed values
         * @return Custom chooser step property builder
         */
        CustomChooserStepPropertyBuilder withAllowValuesProvider(Function<UICallbackContext, List<String>> allowValuesProvider);

        /**
         * Configures the allowed provider from which chooser items will be used populate the column chooser
         * @param allowChooserItemsProvider callback that returns a list of allowed pair value description
         * @return Custom chooser step property builder
         * @since 2.3.0
         */
        CustomChooserStepPropertyBuilder withAllowChooserItemsProvider(BiFunction<UICallbackContext, CustomChooserItemBuilder, List<CustomChooserItem>> allowChooserItemsProvider);
    }
}