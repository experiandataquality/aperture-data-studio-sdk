package com.experian.datastudio.sdk.api.step;

/**
 * Standard exception that will be thrown by custom step
 * @since 2.1.0
 */
public class CustomStepException extends RuntimeException {
    private final int errorCode;

    /**
     * Constructs CustomStepException with error code and message.
     * @param errorCode the customize error code to be displayed on Job details page
     * @param message the message to be logged
     */
    public CustomStepException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * Constructs CustomStepException with error code, message.
     * @param errorCode the customize error code to be displayed on Job details page
     * @param message the message to be logged
     * @param cause the cause
     */
    public CustomStepException(int errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    /**
     * Returns the customize error code to be displayed on Job details page
     * @return the customize error code
     */
    public int getErrorCode() {
        return errorCode;
    }
}
