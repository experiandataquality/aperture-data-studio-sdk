package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.DefaultValueContext;

import java.util.function.Function;

/**
 * Builder for step property that takes a user input in a text field as an input.
 * Extended by NumberStepPropertyBuilder and StringStepPropertyBuilder.
 * @since 2.0.0
 */
public interface InputTextStepPropertyBuilder<T, V> extends StepPropertyBuilder<InputTextStepPropertyBuilder<T, V>, T, V> {

    /**
     * Configures whether this step property must have a value assigned.
     * @param isRequired requires a value to be assigned
     * @return Input text step property builder
     */
    InputTextStepPropertyBuilder<T, V> withIsRequired(boolean isRequired);

    /**
     * Configures the placeholder of the input text field.
     * A placeholder is a hint is displayed in the input field before the user enters a value.
     * @param placeHolder hint to be displayed in input field
     * @return Input text step property builder
     */
    InputTextStepPropertyBuilder<T, V> withPlaceHolder(String placeHolder);

    /**
     * Configures the default value of the input text field.
     * @param value default text field value
     * @return Input text step property builder
     */
    InputTextStepPropertyBuilder<T, V> withDefaultValue(V value);

    /**
     * Configures the default value of the input text field with context.
     * @param defaultValueSupplier supplier for the default text field value
     * @return Input text step property builder
     * @since 2.4.0
     */
    InputTextStepPropertyBuilder<T, V> withDefaultValue(Function<DefaultValueContext, V> defaultValueSupplier);
}
