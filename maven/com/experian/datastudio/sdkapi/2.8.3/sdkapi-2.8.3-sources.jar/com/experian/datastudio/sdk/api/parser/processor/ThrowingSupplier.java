package com.experian.datastudio.sdk.api.parser.processor;

/**
 * The SDK version of Java's Supplier interface which comes with a throw signature.
 *
 * Source: {@link java.util.function.Supplier}
 * Represents a supplier of results.
 * There is no requirement that a new or distinct result be returned each time the supplier is invoked.
 *
 * This is a functional interface whose functional method is get().
 *
 * @param <T> Type of the results supplied by this supplier
 * @param <E> Exception to be thrown
 * @since 2.0.0
 */
@FunctionalInterface
public interface ThrowingSupplier<T, E extends Throwable> {

    /**
     * Gets a result.
     *
     * @return a result
     * @throws E Exception to be thrown
     */
    T get() throws E;

    /**
     * Call to get() method with try-catch for unchecked exceptions.
     * @param f ThrowingSupplier object with exception E
     * @param <T> Type of the results supplied by this supplier
     * @param <E> Exception to be thrown
     * @return Object of type T
     */
    static <T, E extends Throwable> ThrowingSupplier<T, E> unchecked(ThrowingSupplier<T, E> f) {
        return () -> {
            try {
                return f.get();
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        };
    }
}
