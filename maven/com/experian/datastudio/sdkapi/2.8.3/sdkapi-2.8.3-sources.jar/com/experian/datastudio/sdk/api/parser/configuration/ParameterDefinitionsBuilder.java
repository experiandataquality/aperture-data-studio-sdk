package com.experian.datastudio.sdk.api.parser.configuration;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for a list of parameter definitions of a custom parser.
 * Uses {@link com.experian.datastudio.sdk.api.parser.configuration.ParameterDefinitionBuilder}
 * @since 2.0.0
 */
public interface ParameterDefinitionsBuilder {

    /**
     * Adds a new parameter definition through the ParameterDefinitionBuilder.
     * @param parameterDefinitionBuilder callback that returns a parameter definition object
     * @return Parameter definitions builder
     */
    ParameterDefinitionsBuilder add(Function<ParameterDefinitionBuilder, ParameterDefinition> parameterDefinitionBuilder);

    /**
     * Builds a list of parameter definition objects.
     * @return A list of specific concrete parameter definition objects
     */
    List<ParameterDefinition> build();
}
