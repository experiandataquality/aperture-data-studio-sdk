package com.experian.datastudio.sdk.api.parser.processor;

import java.io.InputStream;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Context of a row iterator for a custom parser.
 * @since 2.0.0
 */
public interface RowIteratorContext {

    /**
     * Returns table ID.
     * @return Table ID
     */
    String getTableId();

    /**
     * Returns a supplier of input stream.
     * @return Supplier of input stream
     */
    Supplier<InputStream> getStreamSupplier();

    /**
     * Returns a handle for parser input that can be used by custom parser implementations
     * needing richer input semantics than a bare stream supplier.
     * <p>
     * Existing implementations are preserved through a default adapter.
     *
     * @return Parser input handle
     * @since 2.9.0
     */
    default ParserInputHandle getInputHandle() {
        return ParserInputHandleFactory.fromSupplier(getStreamSupplier());
    }

    /**
     * Returns parameter configuration of row iterator.
     * @param parameterId the ID of the parameter
     * @return Parameter configuration object
     */
    Optional<Object> getParameterConfiguration(String parameterId);

    /**
     * Returns table definition of the custom parser.
     * @return Table definition of the custom parser
     */
    ParserTableDefinition getTableDefinition();

    /**
     * Returns the builder for a closable iterator.
     * @return Builder for a closable iterator
     */
    ClosableIteratorBuilder getClosableIteratorBuilder();

    /**
     * Returns the value of the locale parameter selected by the user.
     * @return the selected locale
     * @since 2.2.0
     */
    Locale getLocale();
}
