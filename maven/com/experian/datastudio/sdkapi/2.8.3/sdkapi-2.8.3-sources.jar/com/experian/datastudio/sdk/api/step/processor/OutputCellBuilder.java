package com.experian.datastudio.sdk.api.step.processor;

/**
 * Builder for defining the value and style of a custom step output cell.
 * @since 2.0.0
 */
public interface OutputCellBuilder {

    /**
     * Configures the value of the cell.
     * @param value value of the cell
     * @return a reference to this object
     */
    StyleAndBuilder withValue(Object value);

    /**
     * @since 2.0.0
     */
    interface Style {

        /**
         * Configures the style of the cell.
         * @param style predefined cell style
         * @return a reference to this object
         */
        Builder withStyle(CustomValueStyle style);
    }
    /**
     * @since 2.0.0
     */
    interface Builder {

        /**
         * Builds an output cell object for the custom step.
         * @return specific concrete output cell object
         */
        OutputCell build();
    }
    /**
     * @since 2.0.0
     */
    interface StyleAndBuilder extends Style, Builder {}

}
