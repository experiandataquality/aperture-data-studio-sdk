package com.experian.datastudio.sdk.api.exporter;

public interface ValidationContext {
    /**
     * Returns the default input context
     *
     * @return Default input context
     */
    ValidationInputContext getDefaultInputContext();

    /**
     * Returns a specific input node using ID
     *
     * @param inputId ID of the input node
     * @return The input context with the specified ID
     */
    ValidationInputContext getAdditionalInputContext(final String inputId);

    /**
     * @param isValid true - valid
     * @param errorMessage Only relevant for invalid status, will be ignored if it's valid.
     * @return instance of ValidationResult
     */
    ValidationResult newValidationResult(boolean isValid, String errorMessage);

    /**
     * Returns the value from a specific custom chooser
     *
     * @param customChooserId The custom chooser's ID
     * @param type            The class of the value's type
     * @param <T>             This describes the type parameter
     * @return The value from the specified custom chooser
     */

    <T> T getChooserValue(String customChooserId, Class<T> type);

    /**
     * Return a valid validation result.
     * @return valid ValidationResult.
     */
    default ValidationResult newValidResult() {
        return newValidationResult(true, "");
    }

}
