package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepProperty;

import java.util.Optional;

/**
 * Defines the UI Callback context of the custom step.
 * @since 2.0.0
 */
public interface UICallbackContext {
    /**
     * Gets the current user defined option.
     *
     * @param <T> The user option type.
     * @return The user defined option.
     */
    <T extends UserOption> T getUserOption();

    /**
     * Convenience method to get step property value when the user option type is {@code DefaultOption} type.
     *
     * @param <T>   The type of value the step property would return. e.g {@link StringStepProperty} would return {@code String} value.
     * @param stepPropertyId the step property id
     * @return The step property value.
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);

    /**
     * Gets whether the input node, specified by {@code inputId}, is connected or not.
     * @param inputId The input id
     * @return {@code true} if the input is connected, otherwise {@code false}
     */
    boolean isInputNodeConnected(String inputId);

    /**
     * Returns the step setting field value as a string based on the step setting field ID specified.
     * @param stepSettingFieldId ID of the step setting field to be returned
     * @return String value of the step setting field
     * @since 2.1.0
     */
    Optional<String> getStepSettingFieldValueAsString(String stepSettingFieldId);

}
