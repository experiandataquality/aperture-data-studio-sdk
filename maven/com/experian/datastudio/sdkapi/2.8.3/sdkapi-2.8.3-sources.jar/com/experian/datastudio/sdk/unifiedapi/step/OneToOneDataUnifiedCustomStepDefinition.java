package com.experian.datastudio.sdk.unifiedapi.step;

import com.experian.datastudio.sdk.unifiedapi.step.processor.*;

public interface OneToOneDataUnifiedCustomStepDefinition extends UnifiedCustomStepAPI {
    /**
     * Process one record at a time.
     *
     * @param context processing context
     * @param input   single incoming data
     * @return single output data
     */
    OutputRecord process(ProcessingContext context, InputRecord input);
}
