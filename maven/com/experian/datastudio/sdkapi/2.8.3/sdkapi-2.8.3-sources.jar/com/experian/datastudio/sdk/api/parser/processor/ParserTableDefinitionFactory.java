package com.experian.datastudio.sdk.api.parser.processor;

/**
 * Factory for table definition of a custom parser.
 * Used by {@link com.experian.datastudio.sdk.api.parser.processor.ParserTableDefinitionFactory}
 * @since 2.0.0
 */
public interface ParserTableDefinitionFactory {

    /**
     * Creates a table definition for the custom parser.
     * @param id ID of the table definition
     * @param name Name of the table definition
     * @param description Description of the table definition
     * @return Parser table definition
     */
    ParserTableDefinition createTableDefinition(String id, String name, String description);
}
