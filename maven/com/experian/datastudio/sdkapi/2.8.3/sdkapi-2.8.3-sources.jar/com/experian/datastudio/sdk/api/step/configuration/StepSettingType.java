package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Predefined step setting types that can be applied to custom step .
 * @since 2.1.0
 */
public enum StepSettingType {
    PASSWORD,
    TEXT,
    TEXTAREA
}
