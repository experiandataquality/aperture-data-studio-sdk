package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Builder for step property that takes a numerical value as an input.
 * @since 2.0.0
 */
public interface NumberStepPropertyBuilder extends InputTextStepPropertyBuilder<NumberStepProperty, Number> {

    /**
     * Configures the minimum value that is accepted as an input for the step property.
     * @param number minimum value
     * @return Number step property builder
     */
    NumberStepPropertyBuilder withMinValue(Number number);

    /**
     * Configures the maximum value that is accepted as an input for the step property.
     * @param number maximum value
     * @return Number step property builder
     */
    NumberStepPropertyBuilder withMaxValue(Number number);

    /**
     * Configures the ability for a user to enter a decimal value as an input for the the step property.
     * @param allowDecimal enables decimal values to be entered into text field
     * @return Number step property builder
     */
    NumberStepPropertyBuilder withAllowDecimal(boolean allowDecimal);
}
