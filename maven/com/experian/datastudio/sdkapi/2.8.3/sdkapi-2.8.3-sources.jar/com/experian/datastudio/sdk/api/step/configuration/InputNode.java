package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Custom step input node.
 * @since 2.0.0
 */
public interface InputNode extends NodeDefinition {

    /**
     * Returns true if the input node is mandatory.
     * @return true if the input node is mandatory, false otherwise
     */
    boolean isRequired();

    /**
     * Returns true if the input label is displayed.
     * @return true if the input label is displayed, false otherwise
     */
    boolean isLabelDisplayed();

    /**
     * Returns the node's label of the custom step.
     * @return the label of the node
     * @since 2.3.0
     */
    String getLabel();
}
