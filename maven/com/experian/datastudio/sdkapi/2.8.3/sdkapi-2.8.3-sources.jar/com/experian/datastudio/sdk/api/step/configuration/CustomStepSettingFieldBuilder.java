package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Builder for a setting field of a custom step.
 * @since 2.0.0
 */
public interface CustomStepSettingFieldBuilder {

    /**
     * Configures the ID of the step setting field.
     * @param id ID of the step setting field
     * @return Name builder
     */
    Name withId(String id);

    /**
     * @since 2.0.0
     */
    interface Name {

        /**
         * Configures the name of the step setting field.
         * @param name name of the step setting field
         * @return Required builder
         */
        Required withName(String name);
    }

    /**
     * @since 2.0.0
     */
    interface Required {

        /**
         * Configures the necessity of the step setting field.
         * @param required step setting requires this field to be assigned
         * @return Custom step setting field builder
         */
        Build withIsRequired(boolean required);
    }

    /**
     * @since 2.0.0
     */
    interface Build {

        /**
         * Configures the ID and type of the step setting field.
         * @param type Step setting type
         * @return Name builder
         * @since 2.1.0
         */
        Build withFieldType(StepSettingType type);

        /**
         * Builds a custom step setting field object.
         * @return Specific concrete custom step setting field object
         */
        CustomStepSettingField build();
    }

}
