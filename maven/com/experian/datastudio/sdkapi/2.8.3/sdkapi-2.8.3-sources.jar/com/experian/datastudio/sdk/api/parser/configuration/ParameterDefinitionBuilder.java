package com.experian.datastudio.sdk.api.parser.configuration;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for a parameter definition of a custom parser
 * Used by {@link com.experian.datastudio.sdk.api.parser.configuration.ParameterDefinitionsBuilder}
 * @since 2.0.0
 */
public interface ParameterDefinitionBuilder {

    /**
     * Configures the ID of the parameter definition.
     * @param id ID of the parameter definition
     * @return Name builder
     */
    ParameterNameBuilder withId(String id);

    /**
     * @since 2.0.0
     */
    interface ParameterNameBuilder {

        /**
         * Configures the name of the parameter definition.
         * @param name name of the parameter definition
         * @return Description builder
         */
        ParameterDescriptionBuilder withName(String name);
    }

    /**
     * @since 2.0.0
     */
    interface ParameterDescriptionBuilder {

        /**
         * Configures the description of the parameter definition.
         * @param description description of the parameter definition
         * @return Mandatory builder
         */
        MandatoryParameterBuilder withDescription(String description);
    }

    /**
     * @since 2.0.0
     */
    interface MandatoryParameterBuilder {

        /**
         * Configures the necessity of the parameter definition.
         * @param shouldBeRequired requires this parameter definition to be assigned
         * @return Parameter type builder
         */
        ParameterTypeBuilder setAsRequired(Boolean shouldBeRequired);
    }

    /**
     * @since 2.0.0
     */
    interface ParameterTypeBuilder {

        /**
         * Configures the parameter type of the parameter definition.
         * @param valueType parser parameter value type
         * @return Display type builder
         */
        DisplayParameterBuilder setTypeAs(ParserParameterValueType valueType);
    }

    /**
     * @since 2.0.0
     */
    interface DisplayParameterBuilder {

        /**
         * Configures the display type of the parameter definition.
         *
         * @param displayType parser parameter display type
         * @return Default value builder
         */
        ParameterDefaultValueBuilder setDisplayTypeAs(ParserParameterDisplayType displayType);

        /**
         * @param displayType   parser parameter display type
         * @param allowedValues that returns a list of allowed values
         * @return Default value builder
         * @since 2.6.0
         * Configures the parameter definition as custom chooser (eg: dropdown)
         */
        ParameterDefaultValueBuilder setDisplayTypeAs(ParserParameterCustomSelectionType displayType, List<String> allowedValues);
    }

    /**
     * @since 2.0.0
     */
    interface ParameterDefaultValueBuilder {

        /**
         * Configures the default parameter value as a string.
         * @param value default string value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsString(String value);

        /**
         * Configures the default parameter value as a boolean.
         * @param value default boolean value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsBoolean(boolean value);

        /**
         * Configures the default parameter value as a number.
         * @param value default numerical value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsNumber(long value);

        /**
         * Configures the default parameter value as a character.
         * @param value default character value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsCharacter(char value);

        /**
         * Configures the default parameter value as a string.
         * @param getDefaultValue callback that returns the default string value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsString(Function<ParameterContext, String> getDefaultValue);

        /**
         * Configures the default parameter value as a boolean.
         * @param getDefaultValue callback that returns the default boolean value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsBoolean(Function<ParameterContext, Boolean> getDefaultValue);

        /**
         * Configures the default parameter value as a number.
         * @param getDefaultValue callback that returns the default numerical value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsNumber(Function<ParameterContext, Long> getDefaultValue);

        /**
         * Configures the default parameter value as a character.
         * @param getDefaultValue callback that returns the default character value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsCharacter(Function<ParameterContext, Character> getDefaultValue);
    }

    /**
     * @since 2.0.0
     */
    interface AffectsTableStructureBuilder {

        /**
         * Configures the flag for table structure changes.
         * @param affectsTableStructure flag for table structure changes
         * @return Parameter definition builder
         */
        DefinitionBuilder affectsTableStructure(Boolean affectsTableStructure);
    }

    /**
     * @since 2.0.0
     */
    interface DefinitionBuilder {

        /**
         * Builds a parameter definition object.
         * @return Specific concrete parameter definition object
         */
        ParameterDefinition build();
    }

     /**
     * @since 2.6.0
     */
    interface CustomChooserDefaultValueBuilder {
        /**
         * Configures the default parameter value as a string.
         * @param value default string value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsString(String value);

        /**
         * Configures the default parameter value as a string.
         * @param getDefaultValue callback that returns the default string value
         * @return Affects table structure builder
         */
        AffectsTableStructureBuilder withDefaultValueAsString(Function<ParameterContext, String> getDefaultValue);
    }
}
