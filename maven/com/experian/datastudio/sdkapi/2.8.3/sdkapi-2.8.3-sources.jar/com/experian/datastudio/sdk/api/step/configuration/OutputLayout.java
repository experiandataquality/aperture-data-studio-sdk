package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;

import java.util.List;

/**
 * Defines the output layout of the custom step.
 * @since 2.0.0
 */
public interface OutputLayout {

    /**
     * Returns the ID of the output layout.
     * @return ID of the output layout
     */
    String getOutputId();

    /**
     * Returns the output columns based on the output column builder context.
     * @param context Output column builder context
     * @return List of columns for the output layout
     */
    List<Column> getColumns(OutputColumnBuilderContext context);
}
