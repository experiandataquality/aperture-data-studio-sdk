package com.experian.datastudio.sdk.unifiedapi.step.configuration;

import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.CustomStepSetting;
import com.experian.datastudio.sdk.api.step.configuration.InputNode;
import com.experian.datastudio.sdk.api.step.configuration.OutputLayout;
import com.experian.datastudio.sdk.api.step.configuration.OutputNode;
import com.experian.datastudio.sdk.api.step.configuration.StepIcon;
import com.experian.datastudio.sdk.api.step.configuration.StepProperty;
import com.experian.datastudio.sdk.api.step.configuration.UICallbackContext;

import java.util.List;
import java.util.Optional;

public interface UnifiedStepConfiguration {
    /**
     * Returns the step properties that are associated with the custom step.
     *
     * @return List of Step Properties
     */
    List<StepProperty> getStepProperties();

    /**
     * Returns the default configuration option of the custom step.
     *
     * @return User option
     */
    UserOption getDefaultStepOptions();

    /**
     * Returns the output layout of the custom step.
     *
     * @return List of output layouts
     */
    List<OutputLayout> getOutputLayouts();

    /**
     * Returns the input nodes that are associated with the custom step.
     *
     * @return List of input Node Definitions
     */
    Optional<InputNode> getInputNode();

    /**
     * Returns the output nodes that are associated with the custom step.
     *
     * @return List of output Node Definitions
     */
    List<OutputNode> getOutputNode();

    /**
     * Returns a flag to determine if the custom step is complete.
     *
     * @param context the UI context from where the value of {@link StepProperty} could be retrieved.
     * @return {@code true} if the custom step is complete, otherwise {@code false}
     */
    boolean isComplete(UICallbackContext context);

    /**
     * Returns step setting of the custom step.
     *
     * @return Custom step setting
     */
    Optional<CustomStepSetting> getStepSetting();

    /**
     * Returns the icon of the custom step.
     *
     * @return step icon
     */
    StepIcon getIcon();
}
