package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.Column;
import com.experian.datastudio.sdk.api.step.configuration.DefaultColumnContext;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for step property that provides a column chooser for user to select an input.
 * @since 2.0.0
 */
public interface ColumnChooserStepPropertyBuilder extends StepPropertyBuilder<ColumnChooserStepPropertyBuilder, ColumnChooserStepProperty, List<String>> {

    /**
     * Configures the ability for a user to select multiple values from the column chooser.
     * @param isEnabled enables multiple value selection
     * @return Column chooser step property builder
     */
    ColumnChooserStepPropertyBuilder withMultipleSelect(boolean isEnabled);

    /**
     * Configures the ability for a user to select all values from the column chooser.
     * @param isEnabled enables selection of all values
     * @return Column chooser step property builder
     */
    ColumnChooserStepPropertyBuilder withAllowSelectAll(boolean isEnabled);

    /**
     * Configures the ability for a user to search for a specified value in the column chooser.
     * @param isEnabled enables search for specified value
     * @return Column chooser step property builder
     */
    ColumnChooserStepPropertyBuilder withAllowSearch(boolean isEnabled);

    /**
     * Configures whether this step property must have a value assigned.
     * @param isRequired requires a value to be assigned
     * @return Column chooser step property builder
     */
    ColumnChooserStepPropertyBuilder withIsRequired(boolean isRequired);

    /**
     * Configures automatic selection of values in the column chooser based on a list of specified data tags.
     * @param tags list of specified data tags
     * @return Column chooser step property builder
     */
    ColumnChooserStepPropertyBuilder withAutoSelectColumnsWithTag(List<String> tags);

    /**
     * Configures the default value of the input text field with context.
     * @param defaultValueSupplier supplier for the default text field value
     * @return Input text step property builder
     * @since 2.4.0
     */
    ColumnChooserStepPropertyBuilder withDefaultValue(Function<DefaultColumnContext, List<Column>> defaultValueSupplier);

    /**
     * @since 2.0.0
     */
    interface InputNodeBuilder {

        /**
         * Configures the input node from which values will be used populate the column chooser
         * @param inputId ID of input node
         * @return Column chooser step property builder
         */
        ColumnChooserStepPropertyBuilder forInputNode(String inputId);
    }
}
