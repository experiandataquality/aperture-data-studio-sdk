package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StepPropertyCommandType;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * INTERNAL USE
 * Internal API to bridge custom step's configuration with data studio.
 * @since 2.0.0
 */
public interface StepPropertyConfig {

    /**
     * Returns the supplier of a string text argument.
     * @return Supplier of a string text argument
     */
    Function<StepPropertyContext, String> getArgTextSupplier();

    /**
     * Returns the supplier of the icon used for the custom step.
     * @return Supplier of the icon used for the custom step
     */
    Function<StepPropertyContext, StepIcon> getIconSupplier();

    /**
     * Returns the supplier for determining if the custom step is defined.
     * @return Supplier for determining if the custom step is defined
     */
    Predicate<StepPropertyContext> getIsDefinedSupplier();

    /**
     * Returns the supplier for determining if the custom step is disabled.
     * @return Supplier for determining if the custom step is disabled
     */
    Predicate<StepPropertyContext> getIsDisabledSupplier();

    /**
     * Returns the handler for when a text is clicked.
     * @return Handler for when a text is clicked
     */
    Function<StepPropertyContext, Runnable> getTextClickedHandler();

    /**
     * Returns the handler for when an icon is clicked.
     * @return Handler for when an icon is clicked
     */
    Function<StepPropertyContext, Runnable> getIconClickedHandler();

    /**
     * Returns the supplier of the label for the custom step.
     * @return Supplier of the label for the custom step
     */
    Function<StepPropertyContext, String> getLabelSupplier();

    /**
     * Returns the supplier for determining if the custom step is connected.
     * @return Supplier for determining if the custom step is connected
     */
    Predicate<StepPropertyContext> getIsConnectedSupplier();

    /**
     * Returns the supplier of the connected text for the custom step.
     * @return Supplier of the connected text for the custom step
     */
    Function<StepPropertyContext, String> getConnectedTextSupplier();

    /**
     * Returns the handler for when an input is connected.
     * @return Handler for when an input is connected
     */
    Function<StepPropertyContext, Runnable> getInputConnectedHandler();

    /**
     * Returns the supplier of {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.StepPropertyCommandType}.
     * The {@code StepPropertyCommandType} determines the display type of the step property arg text in the UI.
     * E.g: if the supplier return {@code StepPropertyCommandType.DROPDOWN}, the arg text UI will be displayed in a box
     * with a down arrow to indicate that it's a dropdown.
     * @return The command type or {@code Optional.empty()} to display arg text as it is.
     */
    Function<StepPropertyContext, Optional<StepPropertyCommandType>> getStepPropertyCommandTypeSupplier();

    /**
     * Return the supplier of value icon type when the value is shown as dropdown.
     * @return Supplier of value icon type.
     * @since 2.5.0
     */
    Function<StepPropertyContext, StepIcon> getValueIconSupplier();
}
