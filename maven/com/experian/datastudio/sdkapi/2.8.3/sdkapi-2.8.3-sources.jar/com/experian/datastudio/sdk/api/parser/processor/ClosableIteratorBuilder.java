package com.experian.datastudio.sdk.api.parser.processor;

import java.io.IOException;
import java.util.List;

/**
 * Builder for an iterator for the custom parser that can be closed after processing.
 * @since 2.0.0
 */
public interface ClosableIteratorBuilder {

    /**
     * Configures the custom parser to check if the iterator has next line.
     * @param hasNext supplier for flag for the presence of the next line
     * @return Closable iterator builder
     */
    WithNextBuilder withHasNext(ThrowingSupplier<Boolean, IOException> hasNext);

    /**
     * @since 2.0.0
     */
    interface WithNextBuilder {
        /**
         * Configures the custom parser to return the next line of the iterator.
         *
         * @param next supplier for a list of strings in the next line
         * @return Closable iterator builder
         */
        WithProgressBuilder withNext(ThrowingSupplier<List<String>, IOException> next);
    }

    /**
     * @since 2.0.0
     */
    interface WithProgressBuilder {
        /**
         * Configures the custom parser to return the estimated progress.
         *
         * @param getEstimationProgress supplier for current estimated progress.
         * @return Closable iterator builder
         */
        WithCloseBuilder withProgress(ThrowingSupplier<Double, IOException> getEstimationProgress);
    }

    /**
     * @since 2.0.0
     */
    interface  WithCloseBuilder {
        /**
         * Configures an executable instance of a closer for the iterator.
         * @param closer a runnable instance of a closer for the iterator
         * @return Closable iterator builder
         */
        IteratorBuilder withClose(ThrowingRunnable<IOException> closer);
    }

    /**
     * @since 2.0.0
     */
    interface IteratorBuilder {
        /**
         * Builds a closable iterator object.
         *
         * @return Specific concrete closable iterator object
         */
        ClosableIterator<List<String>> build();
    }
}
