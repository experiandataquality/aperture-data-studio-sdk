package com.experian.datastudio.sdk.api.step.configuration;

import java.util.function.Function;

/**
 * Builder for step settings of a custom step. A step setting can have multiple fields.
 * @since 2.0.0
 */
public interface CustomStepSettingBuilder {

    /**
     * Adds a field to the step settings of the custom step.
     * @param builder builder for custom step setting field
     * @return Custom step setting builder
     */
    Build addField(Function<CustomStepSettingFieldBuilder, CustomStepSettingField> builder);

    /**
     * @since 2.0.0
     */
    interface Build extends CustomStepSettingBuilder {

        /**
         * Builds an custom step setting object for the custom step.
         * @return Specific concrete custom step setting object
         */
        CustomStepSetting build();
    }

}
