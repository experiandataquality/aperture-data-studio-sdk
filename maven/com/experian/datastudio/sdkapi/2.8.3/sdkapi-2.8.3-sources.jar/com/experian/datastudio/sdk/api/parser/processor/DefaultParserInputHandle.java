package com.experian.datastudio.sdk.api.parser.processor;

import java.io.InputStream;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Default {@link ParserInputHandle} implementation backed by supplied stream and optional metadata.
 *
 * @since 2.9.0
 */
public class DefaultParserInputHandle implements ParserInputHandle {
    private final Supplier<InputStream> streamSupplier;
    private final Path localPath;
    private final Supplier<SeekableByteChannel> seekableChannelSupplier;

    public DefaultParserInputHandle(final Supplier<InputStream> streamSupplier,
                                    final Path localPath,
                                    final Supplier<SeekableByteChannel> seekableChannelSupplier) {
        this.streamSupplier = streamSupplier;
        this.localPath = localPath;
        this.seekableChannelSupplier = seekableChannelSupplier;
    }

    @Override
    public InputStream openStream() {
        return streamSupplier.get();
    }

    @Override
    public Optional<Path> getLocalPath() {
        return Optional.ofNullable(localPath);
    }

    @Override
    public Supplier<SeekableByteChannel> getSeekableChannelSupplier() {
        if (seekableChannelSupplier == null) {
            throw new UnsupportedOperationException("Seekable channel access is not supported for this input handle.");
        }
        return seekableChannelSupplier;
    }
}

