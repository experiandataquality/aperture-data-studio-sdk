package com.experian.datastudio.sdk.api.step.processor.cache;

import java.util.concurrent.TimeUnit;

/**
 * Defines the time-to-live (expiry) of a {@link com.experian.datastudio.sdk.api.step.processor.cache.StepCache}'s entry.
 * @since 2.0.0
 */
public interface StepCacheTtl {

    long getTime();

    TimeUnit getTimeUnit();

}
