package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Predefined node types that can be applied to custom step (data/process).
 * @since 2.0.0
 */
public enum NodeType {
    DATA,
    PROCESS
}
