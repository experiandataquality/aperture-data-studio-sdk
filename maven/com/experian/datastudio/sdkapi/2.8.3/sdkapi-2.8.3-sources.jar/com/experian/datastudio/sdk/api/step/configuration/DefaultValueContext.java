package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepProperty;

import java.util.Optional;

/**
 * Context for step property when setting default value.
 * Extended by DefaultColumnContext.
 * @since 2.4.0
 */
public interface DefaultValueContext {

    /**
     * Convenience method to get step property value when the user option type is {@code DefaultOption} type.
     *
     * @param <T> The type of value the step property would return. e.g {@link StringStepProperty} would return {@code String} value.
     * @param stepPropertyId the step property id
     * @return The step property value.
     */
    <T> Optional<T> getStepPropertyValue(String stepPropertyId);

    /**
     * Returns the step setting field value as a string based on the step setting field ID specified.
     * @param stepSettingFieldId ID of the step setting field to be returned
     * @return String value of the step setting field
     */
    Optional<String> getStepSettingFieldValueAsString(String stepSettingFieldId);
}
