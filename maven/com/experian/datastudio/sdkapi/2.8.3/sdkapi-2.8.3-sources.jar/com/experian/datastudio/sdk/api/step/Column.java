package com.experian.datastudio.sdk.api.step;

import java.util.Collection;

/**
 * Definition of a column in a custom step.
 * @since 2.0.0
 */
public interface Column {
    /**
     * Returns the ID of the column.
     * @return ID of the column
     */
    String getId();

    /**
     * Returns the name of the column.
     * @return Name of the column
     */
    String getName();

    /**
     * Returns the data tags associated with the column.
     * @return Collection of data tags associated with the column
     */
    Collection<String> getTags();
}
