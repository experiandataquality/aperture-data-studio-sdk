package com.experian.datastudio.sdk.api.parser.configuration;

import java.util.List;

/**
 * Parameter definition of a custom parser
 * Used by {@link com.experian.datastudio.sdk.api.parser.configuration.ParameterDefinitionBuilder}
 *
 * @since 2.0.0
 */
public interface ParameterDefinition {

    /**
     * Returns the ID of the parameter definition.
     * @return ID of the parameter definition
     */
    String getId();

    /**
     * Returns the name of the parameter definition.
     * @return Name of the parameter definition
     */
    String getName();

    /**
     * Returns the description of the parameter definition.
     * @return Description of the parameter definition
     */
    String getDescription();

    /**
     * Returns the necessity of the parameter definition.
     * @return Necessity of the parameter definition
     */
    boolean isRequired();

    /**
     * Returns the parameter type of the parameter definition.
     * @return Parameter value type of the parameter definition
     */
    ParserParameterValueType getType();

    /**
     * Returns the display type of the parameter definition.
     *
     * @return Parameter display type of the parameter definition
     */
    ParserParameterDisplayType getUIType();

    /***
     * Return the custom selection display type of the parameter definition
     * @return custom display type of the parameter definition
     * @since 2.6.0
     */
    ParserParameterCustomSelectionType getCustomSelectionUIType();

    /***
     * Return the available values for selection in the custom selection UI
     * @return available values for selection in the custom selection UI
     * @since 2.6.0
     */
    List<String> getAllowedValues();

    /**
     * Returns the default parameter value as a string.
     *
     * @param parameterContext the parameter context of the custom parser
     * @return Default string value
     */
    Object getDefaultValue(ParameterContext parameterContext);

    /**
     * Returns the flag for table structure changes.
     * @return Flag for table structure changes
     */
    boolean affectsTableStructure();
}
