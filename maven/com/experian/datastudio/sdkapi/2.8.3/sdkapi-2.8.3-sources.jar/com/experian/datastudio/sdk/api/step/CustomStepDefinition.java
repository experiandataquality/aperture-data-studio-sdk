package com.experian.datastudio.sdk.api.step;

import com.experian.datastudio.sdk.api.CustomDefinition;
import com.experian.datastudio.sdk.api.step.configuration.StepConfiguration;
import com.experian.datastudio.sdk.api.step.configuration.StepConfigurationBuilder;
import com.experian.datastudio.sdk.api.step.processor.StepProcessor;
import com.experian.datastudio.sdk.api.step.processor.StepProcessorBuilder;

/**
 * Definition of a custom step, encompasses step configuration, step processor, and custom type metadata.
 * @see     com.experian.datastudio.sdk.api.step.configuration.StepConfiguration
 * @see     com.experian.datastudio.sdk.api.step.processor.StepProcessor
 * @see     com.experian.datastudio.sdk.api.CustomTypeMetadata
 * @since   2.0.0
 */
public interface CustomStepDefinition extends CustomDefinition {

    /**
     * Creates the custom step configuration.
     * @see com.experian.datastudio.sdk.api.step.configuration.StepConfiguration
     * @param configurationBuilder Step configuration builder
     * @return Step configuration of the custom step
     */
    StepConfiguration createConfiguration(StepConfigurationBuilder configurationBuilder);

    /**
     * Creates the custom step processor.
     * @see com.experian.datastudio.sdk.api.step.processor.StepProcessor
     * @param processorBuilder Step processor builder
     * @return Step processor of the custom step
     */
    StepProcessor createProcessor(StepProcessorBuilder processorBuilder);
}
