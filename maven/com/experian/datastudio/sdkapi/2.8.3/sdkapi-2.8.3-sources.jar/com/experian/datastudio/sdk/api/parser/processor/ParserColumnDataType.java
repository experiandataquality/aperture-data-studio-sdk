package com.experian.datastudio.sdk.api.parser.processor;

/**
 * Predefined column data types that can be applied to custom parser.
 * @since 2.0.0
 */
public enum ParserColumnDataType {
    NUMERIC,
    ALPHANUMERIC,
    DATE,
    UNKNOWN
}
