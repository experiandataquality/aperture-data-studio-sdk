package com.experian.datastudio.sdk.api.step.processor;

/**
 * Predefined style that can be applied to custom step output cell.
 * @since 2.0.0
 */
public enum CustomValueStyle {

    ERROR,
    WARNING,
    SUCCESS,
    INFO
}
