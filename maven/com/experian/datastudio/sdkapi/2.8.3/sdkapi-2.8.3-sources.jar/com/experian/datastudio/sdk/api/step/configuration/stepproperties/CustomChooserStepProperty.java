package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

import com.experian.datastudio.sdk.api.step.configuration.StepProperty;
import com.experian.datastudio.sdk.api.step.configuration.UICallbackContext;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * Step property that provides a custom chooser for user to select an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.CustomChooserStepPropertyBuilder}
 * @since 2.0.0
 */
public interface CustomChooserStepProperty extends StepProperty<List<String>> {

    /**
     * Returns the allowed provider from which values will be used populate the column chooser
     * @return Callback that returns a list of allowed values
     * @deprecated Since 2.3.0. Replaced by {{@link #getAllowedChooserItemsProvider()}}
     */
    @Deprecated
    Function<UICallbackContext, List<String>> getAllowedValuesProvider();

    /**
     * Returns the allowed provider from which chooser items will be used populate the column chooser
     * @return Callback that returns a list of allowed chooser items
     * @since 2.3.0
     */
    BiFunction<UICallbackContext, CustomChooserItemBuilder, List<CustomChooserItem>> getAllowedChooserItemsProvider();

    /**
     * Returns the ability for a user to select multiple values from the custom chooser.
     * @return Flag of ability for multiple value selection
     */
    boolean isMultipleSelectEnabled();

    /**
     * Returns the ability for a user to select all values from the custom chooser.
     * @return Flag of ability for selection of all values
     */
    boolean isSelectAllEnabled();

    /**
     * Returns the ability for a user to search of a specified value in the custom chooser.
     * @return Flag of ability for search of specified value
     */
    boolean isSearchEnabled();
}