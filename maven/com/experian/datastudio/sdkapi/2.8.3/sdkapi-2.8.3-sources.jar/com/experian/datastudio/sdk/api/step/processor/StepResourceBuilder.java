package com.experian.datastudio.sdk.api.step.processor;

import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Builder for defining the step resource of a custom step.
 * @param <T> type of the step resource
 * @since 2.0.0
 */
public interface StepResourceBuilder<T> {

    /**
     * Configures the unique ID of the step resource.
     * @param resourceId ID of the step resource
     * @return Supplier builder of the step resource type
     */
    Supplier<T> withResourceId(String resourceId);

    /**
     * @param <T> type of the step resource
     * @since 2.0.0
     */
    interface Supplier<T> {

        /**
         * Configures the supplier for the step resource.
         * @param supplier callback that returns an object of the step resource type
         * @return Builder of step resource type
         */
        Builder<T> withSupplier(Function<StepResourceContext, T> supplier);
    }

    /**
     * @param <T> type of the step resource
     * @since 2.0.0
     */
    interface Builder<T> {

        /**
         * Configures a consumer to close the step resource after processing.
         * @param closer consumer of the step resource type to close the resource
         * @return Builder of step resource type
         */
        Builder<T> withCloser(Consumer<T> closer);

        /**
         * Builds the step resource object.
         * @return Specific concrete step resource object
         */
        StepResource<T> build();
    }
}
