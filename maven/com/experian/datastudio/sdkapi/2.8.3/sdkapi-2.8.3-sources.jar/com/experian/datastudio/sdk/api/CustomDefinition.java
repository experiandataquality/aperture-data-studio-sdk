package com.experian.datastudio.sdk.api;

/**
 * Definition that is shared between a custom step/parser.
 * Creates metadata for custom step/parser.
 * @see     com.experian.datastudio.sdk.api.CustomTypeMetadata
 * @since   2.0.0
 */
public interface CustomDefinition {

    /**
     * Creates metadata used by a custom step/parser.
     * @param metadataBuilder Custom type metadata builder
     * @return Custom type metadata
     */
    CustomTypeMetadata createMetadata(CustomTypeMetadataBuilder metadataBuilder);
}
