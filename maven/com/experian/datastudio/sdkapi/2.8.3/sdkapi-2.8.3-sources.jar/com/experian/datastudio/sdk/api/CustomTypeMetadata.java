package com.experian.datastudio.sdk.api;

/**
 * The custom step/parser metadata consists of the name of the custom step/parser, description,
 * major version, minor version, patch version, author name, and license type.
 *
 * <p>
 *      One of the 3 main builders required for a custom step/parser:
 *      <ol>
 *          <li>StepConfigurationBuilder</li>
 *          <li>StepProcessorBuilder</li>
 *          <li>CustomTypeMetadataBuilder</li>
 *      </ol>
 *
 * @see     com.experian.datastudio.sdk.api.step.CustomStepDefinition
 * @since   2.0.0
 */
public interface CustomTypeMetadata {

    /**
     * Returns the name of the custom step/parser.
     * @return Name of the custom step/parser
     */
    String getName();

    /**
     * Returns the description of the custom step/parser
     * @return Description of the custom step/parser
     */
    String getDescription();

    /**
     * Returns the custom type version of the custom step/parser
     * @return {@link CustomTypeVersion} of the custom step/parser
     */
    CustomTypeVersion getVersion();

    /**
     * Returns the name of the custom step/parser author
     * @return Name of the custom step/parser author
     */
    String getDeveloper();

    /**
     * Returns the license type associated with the custom step/parser
     * @return License type associated with the custom step/parser
     */
    String getLicense();

}
