package com.experian.datastudio.sdk.api.parser;

import com.experian.datastudio.sdk.api.CustomDefinition;
import com.experian.datastudio.sdk.api.parser.configuration.ParserConfigurationBuilder;
import com.experian.datastudio.sdk.api.parser.configuration.ParserConfiguration;

/**
 * Definition of a custom parser, encompasses parser configuration and custom type metadata.
 * @see     com.experian.datastudio.sdk.api.parser.configuration.ParserConfiguration
 * @see     com.experian.datastudio.sdk.api.CustomTypeMetadata
 * @since   2.0.0
 */
public interface CustomParserDefinition extends CustomDefinition {

    /**
     * Creates the custom parser configuration.
     * @param parserConfigurationBuilder Parser configuration builder
     * @return Parser configuration of the custom parser
     */
    ParserConfiguration createConfiguration(ParserConfigurationBuilder parserConfigurationBuilder);
}
