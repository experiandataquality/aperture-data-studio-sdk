package com.experian.datastudio.sdk.unifiedapi.step.configuration;

import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.CustomStepSetting;
import com.experian.datastudio.sdk.api.step.configuration.CustomStepSettingBuilder;
import com.experian.datastudio.sdk.api.step.configuration.NodeDefinition;
import com.experian.datastudio.sdk.api.step.configuration.OutputLayout;
import com.experian.datastudio.sdk.api.step.configuration.OutputLayoutBuilder;
import com.experian.datastudio.sdk.api.step.configuration.StepIcon;
import com.experian.datastudio.sdk.api.step.configuration.StepPropertiesBuilder;
import com.experian.datastudio.sdk.api.step.configuration.StepProperty;
import com.experian.datastudio.sdk.api.step.configuration.UICallbackContext;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Builder for step configuration of unified custom step.
 *
 */
public interface UnifiedStepConfigurationBuilder {
    /**
     * Configures the input and output nodes that are associated with the custom step.
     *
     * @param nodeBuilder list of Node Definitions
     * @return Add step properties builder
     */
    UnifiedStepConfigurationBuilder withNodes(Function<UnifiedStepNodeBuilder, List<NodeDefinition>> nodeBuilder);

    /**
     * Configures the step properties that are associated with the custom step.
     *
     * @param stepPropertyBuilder list of Step Properties
     * @return Complete and output definition builder
     */
    UnifiedStepConfigurationBuilder withStepProperties(Function<StepPropertiesBuilder, List<StepProperty>> stepPropertyBuilder);

    /**
     * Configures the handler to determine if the custom step is complete.
     *
     * @param isCompleteHandler callback to determine if custom step is complete
     * @return Output definition builder
     */
    UnifiedStepConfigurationBuilder withIsCompleteHandler(Predicate<UICallbackContext> isCompleteHandler);

    /**
     * Configures the output layout of the custom step.
     *
     * @param outputLayoutBuilder builder to configure individual output layout
     * @return Configuration builder
     */
    UnifiedStepConfigurationBuilder withOutputLayouts(Function<OutputLayoutBuilder, List<OutputLayout>> outputLayoutBuilder);

    /**
     * Configures the default configuration option of the custom step.
     *
     * @param userOption user option
     * @return Configuration builder
     */
    UnifiedStepConfigurationBuilder withDefaultOptions(UserOption userOption);

    /**
     * Configures a step setting of the custom step.
     *
     * @param builder builder for custom step setting
     * @return Configuration builder
     */
    UnifiedStepConfigurationBuilder withStepSetting(Function<CustomStepSettingBuilder, CustomStepSetting> builder);

    /**
     * Configures the custom step icon to be displayed.
     *
     * @param icon icon reference
     * @return Configuration builder
     */
    UnifiedStepConfigurationBuilder withIcon(StepIcon icon);

    /**
     * Builds the step configuration object.
     *
     * @return Specific concrete step configuration object
     */
    UnifiedStepConfiguration build();
}
