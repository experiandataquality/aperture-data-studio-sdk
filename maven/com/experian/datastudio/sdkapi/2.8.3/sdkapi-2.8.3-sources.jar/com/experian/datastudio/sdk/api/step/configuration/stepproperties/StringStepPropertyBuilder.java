package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Builder for step property that takes a string from a text field as an input.
 * @since 2.0.0
 */
public interface StringStepPropertyBuilder extends InputTextStepPropertyBuilder<StringStepProperty, String> {
}
