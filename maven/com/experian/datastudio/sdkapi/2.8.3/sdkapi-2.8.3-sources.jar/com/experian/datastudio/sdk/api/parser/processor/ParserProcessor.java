package com.experian.datastudio.sdk.api.parser.processor;

import java.io.IOException;
import java.util.List;

/**
 * Processor for custom parser.
 * @since 2.0.0
 */
public interface ParserProcessor {

    /**
     * Returns the table definitions for the custom parser.
     * @param context Table definition context of the custom parser
     * @return List of table definitions
     * @throws IOException if an I/O error occurs reading from the file
     */
    List<ParserTableDefinition> getTableDefinition(TableDefinitionContext context) throws IOException;

    /**
     * Returns the row iterator of the custom parser.
     * @param context Row iterator context of the custom parser
     * @return Closable iterator of the each parsed line
     * @throws IOException if an I/O error occurs reading from the file
     */
    ClosableIterator<List<String>> getRowIterator(RowIteratorContext context) throws IOException;
}
