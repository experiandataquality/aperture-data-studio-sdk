package com.experian.datastudio.sdk.api.step.configuration;

/**
 * Builder for custom step output node.
 * @since 2.0.0
 */
public interface OutputNodeBuilder {

    Builder withId(String id);

    /**
     * @since 2.0.0
     */
    interface Builder {
        Builder withType(NodeType nodeType);
        Builder withName(String name);
        OutputNode build();
    }

}
