package com.experian.datastudio.sdk.api.step;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * User defined step options to pass in the value of StepConfiguration into Data Studio.
 * StepConfiguration values are stored inside UserOptions.
 * @since 2.0.0
 */
public interface UserOption {

    /**
     * Returns a flag to determine if the custom step has no operation.
     * @return {@code true} if the custom step has no operation, otherwise {@code false}
     */
    boolean hasNoOperation();

    /**
     * Returns a flag to determine if the custom step requires column reconciliation.
     * @return {@code true} if the custom step requires column reconciliation, otherwise {@code false}
     */
    boolean requiresColumnReconciliation();

    /**
     * Map old column IDs to new column IDs
     * @param inputToIdMap Input to ID map
     * @return {@link UserOption} object
     */
    UserOption mapIds(Map<String, Map<String, String>> inputToIdMap);

    /**
     * Returns the referenced column IDs.
     * @param inputLabel Input label
     * @return Collection of referenced column IDs
     */
    Collection<String> retrieveReferencedColumnIds(String inputLabel);

    /**
     * Validate changes to the options.
     * e.g. If input column no longer has certain column ID, remove it
     * @param oldInputColumns Old input columns
     * @param newInputColumns New input columns
     * @return UserOption object
     */
    UserOption validate(Map<String, List<String>> oldInputColumns, Map<String, List<String>> newInputColumns);

    /**
     * Validate parameter references, removing the reference from option if it's not in {@code validParameterIds}.
     * @param validParameterIds Valild parameter ids
     * @return Updated Useroption
     */
    default UserOption validateParameterReferences(Set<String> validParameterIds) {
        return UserOption.this;
    }

    /**
     * Retrieves all referenced workflow parameters.
     * @return list of referenced parameters.
     */
    default Collection<String> retrieveReferencedParameters() {
        return Collections.emptyList();
    }
}
