package com.experian.datastudio.sdk.api.step.processor;

import java.util.function.Function;

/**
 * Builder for processor of a custom step.
 *
 * <p>
 *      The Step Processor contains the main processing logic of the custom step.
 *
 * <p>
 *      One of the 3 main builders required for a custom step:
 *      <ol>
 *          <li>StepConfigurationBuilder</li>
 *          <li>StepProcessorBuilder</li>
 *          <li>CustomTypeMetadataBuilder</li>
 *      </ol>
 *
 * @see     com.experian.datastudio.sdk.api.step.CustomStepDefinition
 * @since 2.0.0
 */
public interface StepProcessorBuilder {

    /**
     * Registers the index for the processing of a custom step
     *
     * @param indexName       An arbitrary name for the index
     * @param builderFunction Function which takes a StepProcessorIndex.Builder as input and returns StepProcessorIndex
     * @return Step processor builder
     * @since 2.4.0
     */
    StepProcessorBuilder registerIndex(final String indexName, Function<StepProcessorIndex.Builder, StepProcessorIndex> builderFunction);

    /**
     * Configures the resources to be used by the custom step.
     *
     * <p>
     *      Resources refer to any shared resources that can be created and used throughout processing.
     *      The resource should be closed after processing.
     * @param builder builder for step resources
     * @param <T> type of the step resource
     * @return Step processor builder
     */
    <T> StepProcessorBuilder registerResource(Function<StepResourceBuilderFactory, StepResource<T>> builder);

    /**
     * Configures the output node to which the results of the custom step will be associated with.
     * @param outputId ID of output node
     * @param processorFunction function defining the step processor logic
     * @return Step processor builder
     */
    Builder forOutputNode(String outputId, StepProcessorFunction processorFunction);

    /**
     * @since 2.0.0
     */
    interface Builder {

        /**
         * Builds the step processor object.
         * @return Specific concrete step processor object
         */
        StepProcessor build();
    }

}
