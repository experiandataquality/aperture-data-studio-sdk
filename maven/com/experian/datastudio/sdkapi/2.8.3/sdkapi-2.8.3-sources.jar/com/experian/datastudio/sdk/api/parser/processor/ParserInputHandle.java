package com.experian.datastudio.sdk.api.parser.processor;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Handle for custom parser input.
 * <p>
 * This abstraction allows parser implementations to request fresh streams for multi-pass processing,
 * while remaining compatible with legacy stream-only implementations.
 *
 * @since 2.9.0
 */
public interface ParserInputHandle extends AutoCloseable {

    /**
     * Opens a new stream from this handle.
     *
     * @return Input stream
     */
    InputStream openStream();

    /**
     * Returns the local path backing this input if available.
     *
     * @return Optional local path
     */
    default Optional<Path> getLocalPath() {
        return Optional.empty();
    }

    /**
     * Returns a supplier for seekable channel access to parser input.
     *
     * @return Supplier of seekable byte channel
     * @throws UnsupportedOperationException if seekable access is not supported
     */
    default Supplier<SeekableByteChannel> getSeekableChannelSupplier() {
        throw new UnsupportedOperationException("Seekable channel access is not supported for this input handle.");
    }

    /**
     * Releases resources for this input handle.
     *
     * @throws IOException if closing fails
     */
    @Override
    default void close() throws IOException {
        // Default no-op for legacy stream-only implementations.
    }
}

