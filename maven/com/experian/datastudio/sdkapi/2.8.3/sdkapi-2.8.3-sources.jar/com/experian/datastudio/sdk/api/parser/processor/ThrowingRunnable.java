package com.experian.datastudio.sdk.api.parser.processor;

/**
 * The SDK version of Java's Runnable interface which comes with a throw signature.
 *
 * Source: {@link Runnable}
 * The Runnable interface should be implemented by any class whose instances are intended to be executed by a thread.
 * The class must define a method of no arguments called run.
 *
 * @param <E> Exception to be thrown
 * @since 2.0.0
 */
@FunctionalInterface
public interface ThrowingRunnable<E extends Throwable> {

    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @throws E Exception to be thrown
     * @see     java.lang.Thread#run()
     */
    void run() throws E;

    /**
     * Call to run() method with try-catch for unchecked exceptions.
     * @param f ThrowingRunnable object with exception E
     * @param <E> Exception to be thrown
     * @return Runnable
     */
    static <E extends Throwable> Runnable unchecked(ThrowingRunnable<E> f) {
        return () -> {
            try {
                f.run();
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        };
    }
}
