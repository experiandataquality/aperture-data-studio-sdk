package com.experian.datastudio.sdk.unifiedapi.step.processor;

import java.util.function.Supplier;

public interface OutputRecordBuilder {
    /**
     * Set the value supplier for a single cell
     *
     * @param columnName    column name of the value supplier
     * @param valueSupplier
     * @return builder
     */
    OutputRecordBuilder setValue(String columnName, Supplier<Object> valueSupplier);

    /**
     * Returns the output record
     *
     * @return output record
     */
    OutputRecord build();
}
