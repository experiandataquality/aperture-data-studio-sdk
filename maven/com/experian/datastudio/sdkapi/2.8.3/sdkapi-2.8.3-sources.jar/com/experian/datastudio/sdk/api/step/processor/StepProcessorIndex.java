package com.experian.datastudio.sdk.api.step.processor;

/**
 * Defines the type of index of the custom step processor.
 *
 * @since 2.4.0
 */
public interface StepProcessorIndex {
    enum IndexType {
        ROW_BASED
    }

    /**
     * Gets the index type of the step processor index
     *
     * @return Index type
     */
    IndexType getType();

    interface Builder {

        /**
         * Returns the row based index builder for the step processor index
         *
         * @return Row based index builder
         */
        RowBasedIndex.Builder indexTypeRows();
    }

}
