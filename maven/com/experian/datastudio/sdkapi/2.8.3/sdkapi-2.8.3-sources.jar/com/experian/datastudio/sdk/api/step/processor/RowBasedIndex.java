package com.experian.datastudio.sdk.api.step.processor;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * One of the index type supported for step processor index
 * Index is row-based
 *
 * @since 2.4.0
 */
public interface RowBasedIndex extends StepProcessorIndex {
    /**
     * Returns a consumer of the {@link ValueContext}
     *
     * @return Consumer of {@link ValueContext}
     */
    Consumer<ValueContext> getIndexConsumer();

    /**
     * Defines the context in all {@link RowBasedIndex} usages
     */
    interface ValueContext {
        /**
         * Puts a row at the specified index
         *
         * @param index
         * @param indexValueSupplier
         */
        void putRow(int index, Supplier<List<?>> indexValueSupplier);

        /**
         * Appends row at last index
         *
         * @param indexValueSupplier
         */
        void appendRow(Supplier<List<?>> indexValueSupplier);

        /**
         * Returns the context for the input to the processor of a custom step
         * For a specific input
         *
         * @param inputId input id as defined by the custom step itself.
         * @return ProcessorInputContext if input id exists.
         */
        Optional<ProcessorInputContext> getInputContext(String inputId);

        /**
         * Returns the step property value of a specific step property
         * Based on the step property ID specified
         *
         * @param stepPropertyId step property ID
         * @param <T> Value of the step property
         * @return step property value if exists.
         */
        <T> Optional<T> getStepPropertyValue(String stepPropertyId);

        /**
         * Convenience method to returns the columns selected by the user.
         * It will returns empty list if the column chooser is invalid or the step property is not a column chooser.
         *
         * @param columnChooserId the column chooser's step property ID
         * @return the list of selected {@link InputColumn}
         */
        List<InputColumn> getColumnFromChooserValues(final String columnChooserId);

        /**
         * Returns the step property value of a specific step property
         * Based on the step property ID specified
         *
         * @param stepSettingFieldId step setting field id as defined by the custom step.
         * @return Step setting field value if exists
         */
        Optional<String> getStepSettingFieldValueAsString(String stepSettingFieldId);
    }

    /**
     * Builder for row based index
     */
    interface Builder {
        /**
         * Consumes index values for a row based index
         *
         * @param indexConsumer provide callback that perform the index writing.
         * @return Final builder of row based index
         */
        FinalBuilder provideIndexValues(final Consumer<ValueContext> indexConsumer);
    }

    interface FinalBuilder {
        /**
         * Builds a row based index object
         *
         * @return Row based index object
         */
        com.experian.datastudio.sdk.api.step.processor.RowBasedIndex build();
    }
}
