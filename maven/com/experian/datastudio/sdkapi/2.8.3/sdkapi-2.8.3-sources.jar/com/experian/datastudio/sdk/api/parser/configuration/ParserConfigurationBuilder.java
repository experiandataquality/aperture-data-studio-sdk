package com.experian.datastudio.sdk.api.parser.configuration;

import com.experian.datastudio.sdk.api.parser.processor.ParserProcessor;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for custom parser configuration.
 * @since 2.0.0
 */
public interface ParserConfigurationBuilder {

    /**
     * Configures the custom parser ID.
     * @param parserId ID of the custom parser
     * @return Supported file extensions builder
     */
    WithSupportedFileExtensionsBuilder withParserId(String parserId);

    /**
     * @since 2.0.0
     */
    interface WithSupportedFileExtensionsBuilder {

        /**
         * Configures the file extensions that the custom parser supports.
         * @param supportedFileExtensionBuilder callback that returns a list of supported file extensions
         * @return Parser parameter definition builder
         */
        ParserParameterDefinitionBuilder withSupportedFileExtensions(Function<SupportedFileExtensionsBuilder,  List<SupportedFileExtension>> supportedFileExtensionBuilder);
    }

    /**
     * @since 2.0.0
     */
    interface ParserParameterDefinitionBuilder {

        /**
         * Configures the custom parser parameter definitions.
         * @param parameterDefinitionBuilder callback that returns a list of custom parser parameter definitions
         * @return Parser processor builder
         */
        ParserProcessorBuilder withParserParameterDefinition(Function<ParameterDefinitionsBuilder, List<ParameterDefinition>> parameterDefinitionBuilder);
    }

    /**
     * @since 2.0.0
     */
    interface ParserProcessorBuilder {

        /**
         * Configures the processor to be used for the custom parser.
         * @param parserProcessor processor to be used for the custom parser
         * @return Parser builder
         */
        ParserBuilder withProcessor(ParserProcessor parserProcessor);
    }

    /**
     * @since 2.0.0
     */
    interface ParserBuilder {

        /**
         * @param requiresSeekableChannel Whether the parser requires a local file to operate
         * @return ParserBuilder
         */
        ParserBuilder requireSeekableChannel(boolean requiresSeekableChannel);

        /**
         * Builds a parser configuration object.
         * @return Specific concrete parser configuration object
         */
        ParserConfiguration build();
    }
}
