package com.experian.datastudio.sdk.api.step.processor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Optional;

/**
 * Standard SDK column value type.
 * @since 2.0.0
 */
public interface CellValue extends Comparable<CellValue> {

    /**
     * Returns cell value type.
     * @return {@link CellValueType}
     */
    CellValueType getType();

    /**
     * Returns the cell value data type.
     * @return {@link CellValueType}
     */
    CellValueDataType getDataType();

    /**
     * Determines if cell value is a null.
     * @return {@code true} if the cell value is a null, otherwise {@code false}
     */
    boolean isNull();

    /**
     * Determines if the cell value is a number.
     * @return {@code true} if the cell value is a number, otherwise {@code false}
     */
    boolean isNumeric();

    /**
     * Determines if the cell value is an integer.
     * @return {@code true} if the cell value is an integer, otherwise {@code false}
     */
    boolean isInteger();

    /**
     * Determines if the cell value data type is a decimal.
     * @return {@code true} if the cell value data type is a decimal, otherwise {@code false}
     */
    boolean isDecimal();

    /**
     * Determines if the cell value data type is alphanumeric.
     * @return  {@code true} if the cell value data type is alphanumeric, otherwise {@code false}
     */
    boolean isAlphanumeric();

    /**
     * Determines if the cell value data type is a date.
     * @return  {@code true} if the cell value data type is a date, otherwise {@code false}
     */
    boolean isDate();

    /**
     * Determines if the cell value type is a list.
     * @return  {@code true} if the cell value type is a list, otherwise {@code false}
     */
    boolean isList();

    /**
     * Determines if the cell value is empty.
     * @return  {@code true} if the cell value is empty, otherwise {@code false}
     */
    boolean isEmpty();

    /**
     * Determines if the cell value is true.
     * @return  {@code true} if the cell value is true, otherwise {@code false}
     */
    boolean isTrue();

    /**
     * Determines if the cell value is false.
     * @return  {@code true} if the cell value is false, otherwise {@code false}
     */
    boolean isFalse();

    /**
     * Determines if the cell value type is a boolean.
     * @return  {@code true} if the cell value type is a boolean, otherwise {@code false}
     */
    boolean isBoolean();

    /**
     * Determines if the cell value type is an error.
     * @return  {@code true} if the cell value type is an error, otherwise {@code false}
     */
    boolean isError();

    /**
     * Determines if the cell value type is a warning.
     * @return  {@code true} if the cell value type is a warning, otherwise {@code false}
     */
    boolean isWarning();

    /**
     * Converts cell value to an object of type T.
     * @param <T> Type of return object
     * @return Object of type T
     */
    <T> T toObject();

    /**
     * Returns the BigDecimal object representation of cell value.
     * @return BigDecimal object representation of cell value
     */
    Optional<BigDecimal> toBigDecimal();

    /**
     * Returns the LocalDate object representation of cell value.
     * @return LocalDate object representation of cell value
     */
    Optional<LocalDate> toLocalDate();

    /**
     * Returns the LocalDateTime object representation of cell value.
     * @return LocalDateTime object representation of cell value
     */
    Optional<LocalDateTime> toLocalDateTime();

    /**
     * Returns the UTC OffsetDateTime object representation of cell value.
     * @return OffsetDateTime object representation of cell value
     */
    Optional<OffsetDateTime> toUtcDateTime();

    /**
     * Returns the long value of cell value.
     * @return Long value of cell value
     */
    long toLong();

    /**
     * Returns the integer value of cell value.
     * @return Integer value of cell value
     */
    int toInt();

    /**
     * Returns the double value of cell value.
     * @return Double value of cell value
     */
    double toDouble();

    /**
     * The method compares the CellValue object that invoked the method to the argument.
     * @param other Cell value to be compared with
     * @param ignoreCase Configures if comparison should ignore case or otherwise
     * @return Integer value of 0 if equal, -1 if less than, 1 if greater than
     */
    int compareTo(CellValue other, boolean ignoreCase);
}
