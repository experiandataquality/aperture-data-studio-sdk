package com.experian.datastudio.sdk.unifiedapi.step.processor;

import com.experian.datastudio.sdk.api.step.Column;

import java.util.List;
import java.util.Optional;

public interface ColumnSchema {
    /**
     * Get all columns metadata.
     *
     * @return columns metadata
     */
    List<Column> getColumns();

    /**
     * Retrieve column index based on column name.
     *
     * @param columnName
     * @return column index or empty if column is not found
     */
    Optional<Integer> indexOfColumnName(final String columnName);

    /**
     * Retrieve column index based on column metadata
     *
     * @param column metadata
     * @return column index or empty if column is not found
     */
    int indexOfColumn(final Column column);

    /**
     * Total number of columns
     *
     * @return total number of columns
     */
    long columnsCount();
}
