package com.experian.datastudio.sdk.api;

/**
 * Builder for metadata of a custom step/parser.
 *
 * <p>
 *      The custom step/parser metadata consists of the name of the custom step/parser, description,
 *      major version, minor version, patch version, author name, and license type.
 *
 * <p>
 *      One of the 3 main builders required for a custom step/parser:
 *      <ol>
 *          <li>StepConfigurationBuilder</li>
 *          <li>StepProcessorBuilder</li>
 *          <li>CustomTypeMetadataBuilder</li>
 *      </ol>
 *
 * @see     com.experian.datastudio.sdk.api.step.CustomStepDefinition
 * @since   2.0.0
 */
public interface CustomTypeMetadataBuilder {

    /**
     * Configures the name of the custom step/parser.
     * @param name name of the custom step/parser
     * @return Description builder
     */
    Description withName(String name);

    /**
     * @since 2.0.0
     */
    interface Description {
        /**
         * Configures the description of the custom step/parser
         * @param description description of the custom step/parser
         * @return {@link MajorVersion} builder
         */
        MajorVersion withDescription(String description);
    }

    /**
     * @since 2.0.0
     */
    interface MajorVersion {
        /**
         * Configures the major version of the custom step/parser
         * @param majorVersion major version of the custom step/parser
         * @return {@link MinorVersion} builder
         */
        MinorVersion withMajorVersion(int majorVersion);
    }

    /**
     * @since 2.0.0
     */
    interface MinorVersion {
        /**
         * Configures the minor version of the custom step/parser
         * @param minorVersion minor version of the custom step/parser
         * @return {@link PatchVersion} builder
         */
        PatchVersion withMinorVersion(int minorVersion);
    }

    /**
     * @since 2.0.0
     */
    interface PatchVersion {
        /**
         * Configures the patch version of the custom step/parser
         * @param patchVersion patch version of the custom step/parser
         * @return {@link Developer} builder
         */
        Developer withPatchVersion(int patchVersion);
    }

    /**
     * @since 2.0.0
     */
    interface Developer {
        /**
         * Configures the name of the custom step/parser author
         * @param developer name of the custom step/parser author
         * @return {@link License} builder
         */
        License withDeveloper(String developer);
    }

    /**
     * @since 2.0.0
     */
    interface License {
        /**
         * Configures the license type associated with the custom step/parser
         * @param license license type associated with the custom step/parser
         * @return CustomTypeMetadata builder
         */
        Builder withLicense(String license);
    }

    /**
     * @since 2.0.0
     */
    interface Builder {
        /**
         * Builds the custom type metadata object.
         * @return specific concrete custom type metadata object
         */
        CustomTypeMetadata build();
    }

}
