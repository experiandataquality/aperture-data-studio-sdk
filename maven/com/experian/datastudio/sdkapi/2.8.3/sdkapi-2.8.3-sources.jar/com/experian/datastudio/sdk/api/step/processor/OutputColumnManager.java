package com.experian.datastudio.sdk.api.step.processor;

import java.util.function.BiFunction;
import java.util.function.LongFunction;

/**
 * Defines the manager for output columns of a custom step.
 * @since 2.0.0
 */
public interface OutputColumnManager {

    /**
     * Generates the value of a output cell.
     * <blockquote><pre>
     *     outputColumnManager.onValue("Column Name", rowIndex -&gt; {
     *             String generatedValue = "Row " + (rowIndex + 1);
     *             return generatedValue;
     *     });
     * </pre></blockquote>
     * @param outputColumnName output column name as defined in the {@link com.experian.datastudio.sdk.api.step.configuration.OutputLayoutBuilder.OutputColumnBuilder}
     * @param evaluator the function to be executed to generate the cell value
     */
    void onValue(String outputColumnName, LongFunction<?> evaluator);

    /**
     * Generates the value and set the {@link CustomValueStyle} of a output cell.
     * <blockquote><pre>
     *     outputColumnManager.onValue("Column Name", (rowIndex, outputCellBuilder) -&gt; {
     *             String generatedValue = "Row " + (rowIndex + 1);
     *             return outputCellBuilder
     *                     .withValue(generatedValue)
     *                     .withStyle(CustomValueStyle.INFO)
     *                     .build();
     *     });
     * </pre></blockquote>
     * @param outputColumnName output column name as defined in the {@link com.experian.datastudio.sdk.api.step.configuration.OutputLayoutBuilder.OutputColumnBuilder}
     * @param evaluator the function to be executed to generate the cell value and set the cell style
     */
    void onValue(String outputColumnName, BiFunction<Long, OutputCellBuilder, OutputCell> evaluator);
}
