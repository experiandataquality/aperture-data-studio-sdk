package com.experian.datastudio.sdk.api.step.configuration.stepproperties;

/**
 * Step property that takes a string from a text field as an input.
 * Used by {@link com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepPropertyBuilder}
 * @since 2.0.0
 */
public interface StringStepProperty extends InputTextStepProperty<String> {
}
