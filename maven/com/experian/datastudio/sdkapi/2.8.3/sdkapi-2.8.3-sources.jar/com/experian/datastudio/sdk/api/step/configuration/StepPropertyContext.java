package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.Column;
import com.experian.datastudio.sdk.api.step.UserOption;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.CustomChooserItem;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.CustomChooserItemBuilder;

import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * Defines the context in all {@link StepPropertyConfig} callback api.
 * This api expose Data Studio UI api to the custom defined step property to allow
 * the user-defined callback behavior to interact with Data Studio UI.
 * @since 2.0.0
 */
public interface StepPropertyContext {
    /**
     * Gets or creates the context for higher-level abstraction Step Property callback.
     *
     * @return the UI callback context
     */
    UICallbackContext getUICallbackContext();

    /**
     * Dispatches value changed {@code handler} to Data Studio to update the step options.
     *
     * @param handler The value changed handler
     * @param value   The new value.
     * @param <T>     Type of the value.
     */
    <T> void dispatchValueChanged(BiFunction<UserOption, T, UserOption> handler, T value);

    /**
     * Gets columns for the specified {@code inputId}.
     *
     * @param inputId the input id.
     * @return The list of columns.
     */
    List<Column> getColumnsForInputNode(String inputId);

    /**
     * Determines whether the input node specified by the {@code inputId} is connected.
     *
     * @param inputId the input id
     * @return The connected state.
     */
    boolean isInputNodeConnected(String inputId);

    /**
     * Sends a command to Data Studio to show a multi column chooser.
     *
     * @param inputId       The input id where the columns are retrieved from
     * @param handler       The value changed handler when the columns are selected from the chooser UI.
     * @param initialValues The initial pre-selected values.
     * @param showFilter    Whether to show filter in the chooser.
     * @param showSelectAll Whether to show "Select all" in the chooser.
     * @param <T>           The type of value return by the chooser.
     */
    <T> void showMultiColumnChooser(String inputId, BiFunction<UserOption, T, UserOption> handler,
                                    List<String> initialValues, boolean showFilter, boolean showSelectAll);

    /**
     * Sends a command to Data Studio to show a single column chooser.
     *
     * @param inputId The input id where the column are retrieved from
     * @param handler The value changed handler when a column is selected from the chooser UI.
     * @param <T>     The type of value return by the chooser.
     */
    <T> void showColumnChooser(String inputId, BiFunction<UserOption, T, UserOption> handler);

    /**
     * Sends a command to Data Studio to show a multi custom chooser.
     * Custom chooser contains user-defined values.
     *
     * @param handler               The value changed handler when the values are selected from the chooser UI.
     * @param allowedValuesProvider The values provider to show in the chooser.
     * @param initialValues         The initial pre-selected values.
     * @param searchEnabled         Whether to show filter in the chooser.
     * @param selectedAllEnabled    Whether to show "Select all" in the chooser
     * @param <T>                   The type of value return by the chooser
     * @deprecated Since 2.3.0. Replaced by {{@link #showMultiChooserItem(BiFunction, BiFunction, List, boolean, boolean)}}
     */
    @Deprecated
    default <T> void showMultiChooser(BiFunction<UserOption, T, UserOption> handler,
                                      Function<UICallbackContext, List<String>> allowedValuesProvider,
                                      List<String> initialValues, boolean searchEnabled, boolean selectedAllEnabled) {
    }

    /**
     * Sends a command to Data Studio to show a multi custom chooser.
     * Custom chooser contains user-defined chooser items.
     *
     * @param handler               The chooser item changed handler when the values are selected from the chooser UI.
     * @param allowedValuesProvider The chooser items provider to show in the chooser.
     * @param initialValues         The initial pre-selected values.
     * @param searchEnabled         Whether to show filter in the chooser.
     * @param selectedAllEnabled    Whether to show "Select all" in the chooser
     * @param <T>                   The custom chooser item return by the chooser
     * @since 2.3.0
     */
    <T> void showMultiChooserItem(BiFunction<UserOption, T, UserOption> handler,
                                  BiFunction<UICallbackContext, CustomChooserItemBuilder, List<CustomChooserItem>> allowedValuesProvider,
                                  List<String> initialValues, boolean searchEnabled, boolean selectedAllEnabled);

    /**
     * Sends a command to Data Studio to show a custom chooser.
     * Custom chooser contains user-defined values.
     *
     * @param handler               The value changed handler when a value is selected from the chooser UI.
     * @param allowedValuesProvider The values provider to show in the chooser.
     * @param searchEnabled         Whether to show filter in the chooser.
     * @param <T>                   The type of value return by the chooser
     * @deprecated Since 2.3.0. Replaced by {{@link #showChooserItem(BiFunction, BiFunction, boolean)}}
     */
    @Deprecated
    default <T> void showChooser(BiFunction<UserOption, T, UserOption> handler, Function<UICallbackContext, List<String>> allowedValuesProvider,
                                 boolean searchEnabled){
    }

    /**
     * Sends a command to Data Studio to show a custom chooser.
     * Custom chooser contains user-defined chooser items.
     *
     * @param handler               The chooser item changed handler when a value is selected from the chooser UI.
     * @param allowedValuesProvider The chooser items provider to show in the chooser.
     * @param searchEnabled         Whether to show filter in the chooser.
     * @param <T>                   The custom chooser item of value return by the chooser.
     * @since 2.3.0
     */
    <T> void showChooserItem(BiFunction<UserOption, T, UserOption> handler, BiFunction<UICallbackContext, CustomChooserItemBuilder, List<CustomChooserItem>> allowedValuesProvider,
                             boolean searchEnabled);

    /**
     * Determines whether the current arg is defined.
     *
     * @return {@code true} if the arg is defined, otherwise {@code false}
     */
    boolean isArgDefined();

    /**
     * Determines whether the current arg is disabled.
     *
     * @return {@code true} if the arg is disabled, otherwise {@code false}
     */
    boolean isArgDisabled();

    /**
     * Gets the arg connected text.
     *
     * @return the arg connected text.
     */
    String getArgConnectedText();

    /**
     * Gets the title of the step connected to the node specified by {@code inputId}.
     *
     * @param inputId The input id.
     * @return The connected step title.
     */
    String getConnectedStepTitleToInputNode(String inputId);

    /**
     * Sends a command to Data Studio to show a text box.
     *
     * @param handler                  The value changed handler when the text is entered in the text box UI.
     * @param currentValue             The initial value to pre-populate the text box.
     * @param <T>                      The type of value return by the text box
     */
    <T> void showTextBox(BiFunction<UserOption, T, UserOption> handler,
                         String currentValue);

    /**
     * Sends a command to Data Studio to show a text box with Workflow Parameters chooser.
     *
     * @param handler                  The value changed handler when the text is entered in the text box UI.
     * @param parameterSelectedHandler The handler when a workflow parameter is selected in the UI.
     * @param currentValue             The initial value to pre-populate the text box.
     * @param <T>                      The type of value return by the text box
     * @since 2.5.0
     */
    <T> void showTextBox(BiFunction<UserOption, T, UserOption> handler,
                         BiFunction<UserOption, String, UserOption> parameterSelectedHandler,
                         String currentValue);

    /**
     * Get the underlying workflow parameter name.
     *
     * @param parameterId The parameter id.
     * @return the parameter name if any.
     * @since 2.5.0
     */
    Optional<String> getWorkflowParameterName(String parameterId);

    /**
     * Get the underlying workflow parameter value.
     *
     * @param parameterId The parameter id.
     * @return the parameter name if any.
     * @since 2.5.0
     */
    Optional<String> getWorkflowParameterValue(String parameterId);
}