package com.experian.datastudio.sdk.api.step.configuration;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for a node of a custom step.
 * Used by StepConfigurationBuilder.
 * @since 2.0.0
 */
public interface StepNodeBuilder {

    /**
     * Adds an input node to the custom step.
     * @param inputId ID of the input node
     * @return Step node builder
     */
    StepNodeBuilder addInputNode(String inputId);

    /**
     * Adds an input node to the custom step.
     * @param function function to build input node
     * @return Step node builder
     */
    StepNodeBuilder addInputNode(Function<InputNodeBuilder, InputNode> function);

    /**
     * Adds an output node to the custom step.
     * @param outputId ID of the output node
     * @return Step node builder
     */
    StepNodeBuilder addOutputNode(String outputId);

    /**
     * Adds an output node to the custom step.
     * @param outputId ID of the output node
     * @param name name of the output
     * @return Step node builder
     */
    StepNodeBuilder addOutputNode(String outputId, String name);

    /**
     * Adds an output node to the custom step.
     * @param function function to build the output node
     * @return Step node builder
     */
    StepNodeBuilder addOutputNode(Function<OutputNodeBuilder, OutputNode> function);

    /**
     * Builds a list of node definition objects.
     * @return A list of specific concrete node definition objects
     */
    List<NodeDefinition> build();
}
