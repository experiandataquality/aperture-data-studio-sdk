/**
 * Custom Parser configuration API
 */
package com.experian.datastudio.sdk.api.parser.configuration;