package com.experian.datastudio.sdk.api.step.configuration;

import com.experian.datastudio.sdk.api.step.configuration.stepproperties.BooleanStepPropertyBuilder;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.ColumnChooserStepPropertyBuilder;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.CustomChooserStepPropertyBuilder;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.NumberStepPropertyBuilder;
import com.experian.datastudio.sdk.api.step.configuration.stepproperties.StringStepPropertyBuilder;

import java.util.List;
import java.util.function.Function;

/**
 * Builder for the step properties of a custom step.
 * Used by StepConfigurationBuilder.
 * @since 2.0.0
 */
public interface StepPropertiesBuilder {

    /**
     * Adds a step property to the custom step. Method can be called multiple times to add multiple step properties.
     * @param stepPropertyBuilder builder for a step property
     * @return Step properties builder
     */
    StepPropertiesBuilder addStepProperty(Function<StepPropertyBuilder, StepProperty> stepPropertyBuilder);

    /**
     * Builds a list of step property objects.
     * @return A list of specific concrete step property objects
     */
    List<StepProperty> build();

    /**
     * @since 2.0.0
     */
    interface StepPropertyBuilder {

        /**
         * Configures a step property which has a string input to a text field.
         * @param id ID of the step property
         * @return String step property builder
         */
        StringStepPropertyBuilder asString(String id);

        /**
         * Configures a step property which has a numerical input to a text field.
         * @param id ID of the step property
         * @return Number step property builder
         */
        NumberStepPropertyBuilder asNumber(String id);

        /**
         * Configures a step property which takes a boolean value as an input.
         * @param id ID of the step property
         * @return Boolean step property builder
         */
        BooleanStepPropertyBuilder asBoolean(String id);

        /**
         * Configures a step property which has a column chooser as an input.
         * @param id ID of the step property
         * @return Column chooser step property builder
         */
        ColumnChooserStepPropertyBuilder.InputNodeBuilder asColumnChooser(String id);

        /**
         * Configures a step property which has a custom chooser as an input.
         * @param id ID of the step property
         * @return Custom chooser step property builder
         */
        CustomChooserStepPropertyBuilder.AllowValuesProviderBuilder asCustomChooser(String id);

    }
}
