package com.experian.datastudio.sdk.api.exporter;

import java.util.Collection;

public interface InputColumnMetadata {
    /**
     * Returns the ID of the input column of a custom file generator.
     *
     * @return ID of the input column
     */
    String getId();

    /**
     * Returns the name of the input column of a custom file generator.
     *
     * @return Name of the input column
     */
    String getName();

    /**
     * Returns the data tags associated with the column.
     *
     * @return Collection of data tags associated with the column
     * @since 2.3.0
     */
    Collection<String> getTags();
}
