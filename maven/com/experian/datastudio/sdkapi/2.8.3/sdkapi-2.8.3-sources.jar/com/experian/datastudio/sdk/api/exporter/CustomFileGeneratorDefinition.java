package com.experian.datastudio.sdk.api.exporter;

import com.experian.datastudio.sdk.api.CustomDefinition;

/**
 * The main interface of custom exporter plugin.
 */
public interface CustomFileGeneratorDefinition extends CustomDefinition {
    /**
     * Creates the custom file generator configuration.
     *
     * @param configBuilder generator configuration builder
     * @return generator configuration of custom file generator
     */
    GeneratorConfig configure(GeneratorConfig.Builder configBuilder);

    /**
     * Generates file with generator context
     *
     * @param context generator context
     */
    void generate(GeneratorContext context);

    /**
     * Override this method to provide step configuration level validation.
     *
     * @param context
     * @return
     */
    default ValidationResult validateStepConfiguration(ValidationContext context) {
        return context.newValidResult();
    }
}

